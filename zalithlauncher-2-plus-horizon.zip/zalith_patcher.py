#!/usr/bin/env python3
import json
import os
import pathlib
import re

accent_hex = os.environ.get("ACCENT_HEX", "0xA8C7FA").strip()
if not re.match(r"^0x[0-9a-fA-F]{6}$", accent_hex):
    cleaned = accent_hex.lstrip("#").lstrip("0x")
    accent_hex = f"0x{cleaned.upper()}" if re.match(r"^[0-9a-fA-F]{6}$", cleaned) else "0xA8C7FA"

default_ui_scale = os.environ.get("DEFAULT_UI_SCALE", "100").strip()
if not default_ui_scale.isdigit():
    default_ui_scale = "100"

default_user = os.environ.get("DEFAULT_ELY_USER", "dodo").strip() or "dodo"

htxt = pathlib.Path("/tmp/zalith-extract/horizon.txt")
if htxt.exists():
    for line in htxt.read_text(encoding="utf-8", errors="ignore").splitlines():
        if line.startswith("zalith_accent_hex:"):
            hval = line.split(":", 1)[1].strip().lstrip("#")
            if re.match(r"^[0-9a-fA-F]{6}$", hval):
                accent_hex = f"0x{hval.upper()}"
        elif line.startswith("zalith_ui_scale_pct:"):
            sval = line.split(":", 1)[1].strip()
            if sval.isdigit():
                default_ui_scale = sval
        elif line.startswith("ely_username:") or line.startswith("account_active_user:"):
            uval = line.split(":", 1)[1].strip()
            if uval:
                default_user = uval

# 1. Patch crates/horizon-theme/src/lib.rs
theme_lib = pathlib.Path("crates/horizon-theme/src/lib.rs")
if theme_lib.exists():
    txt = theme_lib.read_text(encoding="utf-8")
    txt = re.sub(r"pub const RADIUS:\s*f32\s*=\s*[0-9.]+;", "pub const RADIUS: f32 = 22.;", txt)
    txt = re.sub(r"pub const RADIUS_PLATE:\s*f32\s*=\s*[0-9.]+;", "pub const RADIUS_PLATE: f32 = 18.;", txt)
    txt = re.sub(
        r"(pub const DARK:\s*Palette\s*=\s*Palette\s*\{[\s\S]*?accent:\s*)0x[0-9a-fA-F_]+",
        rf"\g<1>{accent_hex}",
        txt,
        count=1,
    )
    theme_lib.write_text(txt, encoding="utf-8")
    print(f"[1/6] Berhasil memodifikasi crates/horizon-theme/src/lib.rs (accent={accent_hex})")

# 2. Patch crates/horizon-client/src/ui_theme.rs
ui_theme = pathlib.Path("crates/horizon-client/src/ui_theme.rs")
if ui_theme.exists():
    txt = ui_theme.read_text(encoding="utf-8")
    txt = re.sub(
        r"pub const BG:\s*u32\s*=\s*hex\(P\.page,\s*[0-9]+\);",
        "pub const BG: u32 = hex(P.page, 82);",
        txt,
    )
    txt = re.sub(
        r"pub const RAISED:\s*u32\s*=\s*hex\(P\.ink,\s*[0-9]+\);",
        "pub const RAISED: u32 = hex(P.ink, 80);",
        txt,
    )
    ui_theme.write_text(txt, encoding="utf-8")
    print("[2/6] Berhasil memodifikasi crates/horizon-client/src/ui_theme.rs")

# 3. Patch crates/horizon-client/src/android/launcher_pages.rs
#    - Nama launcher tetap "Horizon Android" (TIDAK diubah ke Zalith!)
#    - UI Bersih & Minimalis (Tanpa AI Slop & Tanpa .hnmod)
#    - Custom Background di Settings langsung berganti saat ditekan (TANPA nyasar ke menu Mods!)
#      serta otomatis memuat file gambar/video (.png/.jpg/.webp/.mp4/.gif) yang di-import pengguna.
launcher_pages = pathlib.Path("crates/horizon-client/src/android/launcher_pages.rs")
if launcher_pages.exists():
    txt = launcher_pages.read_text(encoding="utf-8")
    nl = chr(10)

    old_btn = "        2.0," + nl + "        if accent { color::ACCENT } else { color::RAISED },"
    new_btn = "        18.0," + nl + "        if accent { color::ACCENT } else { color::RAISED },"
    txt = txt.replace(old_btn, new_btn)

    has_page_settings = "Page::Settings" in txt
    card3_action = "Action::Page(Page::Settings)" if has_page_settings else "Action::Profile"

    start_marker = "        if page == Page::Play {"
    end_marker = "        } else if page.is_catalog() {"
    if start_marker in txt and end_marker in txt:
        before, rest = txt.split(start_marker, 1)
        _, after = rest.split(end_marker, 1)
        play_lines = [
            '        // === HORIZON ANDROID: CUSTOM BACKGROUND & SETTINGS BAR ===',
            '        {',
            '            use std::time::{SystemTime, UNIX_EPOCH};',
            '            let htxt_p = self.home.join("horizon.txt");',
            '            let htxt_g = std::fs::read_to_string(&htxt_p).unwrap_or_default();',
            '            let g_pref = |key: &str, def: &str| -> String {',
            '                htxt_g.lines().find_map(|l| {',
            '                    let (k, v) = l.split_once(\':\')?;',
            '                    (k.trim() == key).then(|| v.trim().to_owned())',
            '                }).unwrap_or_else(|| def.to_owned())',
            '            };',
            '            let bg_media_g = g_pref("zalith_bg_media", "none");',
            '            let bg_type_g = g_pref("zalith_bg_type", "image");',
            '            let bg_pal_g = g_pref("zalith_bg_palette", "");',
            '            let prof_slot = (self.catalog.config.profile as usize) % 5;',
            '            let scale_presets_g: [f32; 5] = [100.0, 108.0, 115.0, 90.0, 95.0];',
            '            let ui_pct_g: f32 = scale_presets_g[prof_slot];',
            '',
            '            // Preset tema warna background + file gambar/video yang di-import pengguna',
            '            let theme_names = ["Default Dark", "Midnight Ocean", "Emerald Aurora", "Sunset Amber", "Deep Amethyst"];',
            '            let theme_colors: [[u32; 3]; 5] = [',
            '                [0x0B0F17, 0x111827, 0x1E293B],',
            '                [0x0A192F, 0x112240, 0x1D3557],',
            '                [0x091E1A, 0x10332C, 0x1B4D42],',
            '                [0x1F1216, 0x331B22, 0x4A252E],',
            '                [0x131124, 0x201C3B, 0x2E2854],',
            '            ];',
            '            let mut active_cols: Vec<u32> = bg_pal_g.split(\',\').filter_map(|hex_s| u32::from_str_radix(hex_s.trim(), 16).ok()).collect();',
            '            if active_cols.is_empty() || bg_media_g == "none" {',
            '                active_cols = theme_colors[prof_slot].to_vec();',
            '            }',
            '            if prof_slot > 0 || (bg_media_g != "none" && !bg_media_g.is_empty()) {',
            '                let base_rgb = active_cols[0] & 0x00FFFFFF;',
            '                ui.rounded(0.0, 0.0, w, h, 0.0, 0xFF000000 | base_rgb);',
            '                let phase = if bg_type_g == "video" {',
            '                    (SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis() as f32).unwrap_or(0.0) * 0.002).sin() * 35.0',
            '                } else {',
            '                    0.0',
            '                };',
            '                for (i, c_val) in active_cols.iter().take(4).enumerate() {',
            '                    let rgb = c_val & 0x00FFFFFF;',
            '                    let band_y = (i as f32 * (h * 0.24) + phase).clamp(0.0, h * 0.78);',
            '                    ui.rounded(-20.0, band_y, w + 40.0, h * 0.55, h * 0.25, 0x38000000 | rgb);',
            '                }',
            '                ui.rounded(0.0, 0.0, w, h, 0.0, 0x500B0F17);',
            '            }',
            '',
            '            // Bar Custom Background & Skala UI langsung di halaman Settings (Tidak pindah ke menu Mods!)',
            f'            if {"page == Page::Settings" if has_page_settings else "page != Page::Play && !page.is_catalog()"} {{',
            '                let bar_h = 48.0;',
            '                let bar_y = (h - bar_h - 10.0).max(140.0);',
            '                let bar_x = 20.0;',
            '                let bar_w = (w - 40.0).max(260.0);',
            '                ui.rounded(bar_x, bar_y, bar_w, bar_h, 18.0, color::RAISED);',
            '                let bg_lbl = if bg_media_g != "none" && !bg_media_g.is_empty() {',
            '                    format!("Background: {} · Skala UI {:.0}%", bg_media_g, ui_pct_g)',
            '                } else {',
            '                    format!("Background: {} · Skala UI {:.0}%", theme_names[prof_slot], ui_pct_g)',
            '                };',
            '                let st_fit = ui.fit_text(Face::Medium, 12.0, &bg_lbl, (bar_w * 0.55).max(120.0));',
            '                ui.text(Face::Medium, 12.0, bar_x + 16.0, bar_y + 16.0, color::TEXT, &st_fit);',
            '                let btn_w = (bar_w * 0.36).clamp(150.0, 230.0);',
            '                let btn_x = bar_x + bar_w - btn_w - 10.0;',
            '                button(&mut ui, &mut self.targets, [btn_x, bar_y + 6.0, btn_w, 36.0], "Ganti Background & Skala UI", Action::Profile, true);',
            '            }',
            '        }',
            '        if page == Page::Play {',
            '            use horizon_client::official_install::InstallStage;',
            '            use std::time::{SystemTime, UNIX_EPOCH};',
            '            let installed = horizon_client::official_install::ready(&self.home);',
            '            let installing = self.worker.is_some();',
            '            let progress = *self.install.lock().unwrap();',
            '',
            '            let htxt_path = self.home.join("horizon.txt");',
            '            let htxt_raw = std::fs::read_to_string(&htxt_path).unwrap_or_default();',
            '            let read_pref = |key: &str, def: &str| -> String {',
            '                htxt_raw.lines().find_map(|l| {',
            '                    let (k, v) = l.split_once(\':\')?;',
            '                    (k.trim() == key).then(|| v.trim().to_owned())',
            '                }).unwrap_or_else(|| def.to_owned())',
            '            };',
            '            let scale_presets: [f32; 5] = [100.0, 108.0, 115.0, 90.0, 95.0];',
            '            let ui_scale_pct: f32 = scale_presets[(self.catalog.config.profile as usize) % 5];',
            '            let ui_s: f32 = ui_scale_pct / 100.0;',
            '            let acc_type = read_pref("account_active_type", "elyby");',
            f'            let ely_user = read_pref("ely_username", "{default_user}");',
            '            let tz_offset_h: i64 = read_pref("zalith_timezone_offset_hours", "8").parse::<i64>().unwrap_or(8);',
            '',
            '            let now_secs = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs() as i64).unwrap_or(1793608800);',
            '            let local_secs = (now_secs + tz_offset_h * 3600).max(0) as u64;',
            '            let today_idx = local_secs / 86400;',
            '            let weekday_names = ["Kam", "Jum", "Sab", "Min", "Sen", "Sel", "Rab"];',
            '',
            '            let stats_path = self.home.join("zalith_playtime.txt");',
            '            let stats_raw = std::fs::read_to_string(&stats_path).unwrap_or_default();',
            '            let mut day_minutes: [u32; 7] = [0; 7];',
            '            let mut total_mins: u32 = 0;',
            '            let mut last_ping_sec: u64 = 0;',
            '            for line in stats_raw.lines() {',
            '                if let Some((k, v)) = line.split_once(\':\') {',
            '                    if k == "last_ping" {',
            '                        last_ping_sec = v.parse::<u64>().unwrap_or(0);',
            '                    } else if let (Ok(d_id), Ok(mins)) = (k.parse::<u64>(), v.parse::<u32>()) {',
            '                        total_mins = total_mins.saturating_add(mins);',
            '                        if today_idx >= d_id && (today_idx - d_id) < 7 {',
            '                            let slot = 6 - (today_idx - d_id) as usize;',
            '                            day_minutes[slot] = mins;',
            '                        }',
            '                    }',
            '                }',
            '            }',
            '            if local_secs.saturating_sub(last_ping_sec) >= 60 {',
            '                day_minutes[6] = day_minutes[6].saturating_add(1);',
            '                total_mins = total_mins.saturating_add(1);',
            '                let mut out_s = format!("last_ping:{local_secs}\\n");',
            '                for idx in 0..7 {',
            '                    let d_key = today_idx.saturating_sub((6 - idx) as u64);',
            '                    out_s.push_str(&format!("{d_key}:{}\\n", day_minutes[idx]));',
            '                }',
            '                let _ = std::fs::write(&stats_path, out_s);',
            '            }',
            '            let today_h = (day_minutes[6] as f32) / 60.0;',
            '            let total_h = (total_mins as f32) / 60.0;',
            '            let player_rank = if total_h >= 50.0 {',
            '                "Legend"',
            '            } else if total_h >= 25.0 {',
            '                "Master"',
            '            } else if total_h >= 10.0 {',
            '                "Veteran"',
            '            } else if total_h >= 2.0 {',
            '                "Explorer"',
            '            } else {',
            '                "Novice"',
            '            };',
            '',
            '            let mut mod_count = 0usize;',
            '            if let Ok(rd) = std::fs::read_dir(self.home.join("mods")) {',
            '                for entry in rd.flatten() {',
            '                    let fname = entry.file_name().to_string_lossy().to_ascii_lowercase();',
            '                    if fname.ends_with(".hmod") || fname.ends_with(".jar") { mod_count += 1; }',
            '                }',
            '            }',
            '            let mut shader_count = 0usize;',
            '            if let Ok(rd) = std::fs::read_dir(self.home.join("shaderpacks")) {',
            '                for entry in rd.flatten() {',
            '                    let fname = entry.file_name().to_string_lossy().to_ascii_lowercase();',
            '                    if fname.ends_with(".zip") || fname.ends_with(".hshader") { shader_count += 1; }',
            '                }',
            '            }',
            '',
            '            let total_stages = InstallStage::ALL.len().max(1);',
            '            let current_stage = InstallStage::ALL.iter().position(|s| *s == progress.stage).unwrap_or(0);',
            '            let stage_frac = if progress.total > 0 { (progress.done as f32 / progress.total as f32).clamp(0.0, 1.0) } else { 0.0 };',
            '            let overall_frac = ((current_stage as f32 + stage_frac) / (total_stages as f32)).clamp(0.0, 1.0);',
            '            let overall_pct = (overall_frac * 100.0).round() as u32;',
            '',
            '            // Left Edge Pill ("<")',
            '            let pill_w = (36.0 * ui_s).clamp(28.0, 44.0);',
            '            let body_top = 142.0;',
            '            let body_h = (h - body_top - 18.0).max(190.0);',
            '            ui.rounded(0.0, body_top, pill_w, body_h, 18.0, color::RAISED);',
            '            ui.text(Face::Medium, (15.0 * ui_s).clamp(13.0, 18.0), pill_w * 0.35, body_top + body_h * 0.48, color::TEXT, "<");',
            '            self.targets.push(([0.0, body_top, pill_w, body_h], Action::Page(Page::Installed)));',
            '',
            '            // Clean 2x2 Bento Grid + Right Profile Card',
            '            let right_w = ((if compact { 190.0 } else { 234.0 }) * ui_s).clamp(172.0, (w * 0.34).max(196.0));',
            '            let right_x = (w - right_w - 16.0).max(236.0);',
            '            let grid_x = pill_w + 12.0;',
            '            let grid_w = (right_x - grid_x - 14.0).max(190.0);',
            '            let col_w = (grid_w - 12.0) * 0.5;',
            '            let grid_top = 152.0;',
            '            let grid_h = (h - grid_top - 18.0).max(204.0);',
            '            let row_h = (grid_h - 12.0) * 0.5;',
            '',
            '            ui.text(Face::Medium, (11.0 * ui_s).clamp(9.5, 13.0), grid_x + 4.0, 134.0, color::MUTED, "STATISTIK HARI INI");',
            '',
            '            // Card 1 (Top-Left): Waktu Bermain (7 Hari Terakhir)',
            '            ui.rounded(grid_x, grid_top, col_w, row_h, 20.0, color::RAISED);',
            '            let max_mins = (*day_minutes.iter().max().unwrap_or(&60)).max(30) as f32;',
            '            let step_x = (col_w - 24.0) / 7.0;',
            '            for idx in 0..7 {',
            '                let d_id = today_idx.saturating_sub((6 - idx) as u64);',
            '                let day_lbl = weekday_names[(d_id % 7) as usize];',
            '                let mins = day_minutes[idx];',
            '                let hrs_lbl = format!("{:.1}", (mins as f32) / 60.0).replace(\'.\', ",");',
            '                let ratio = ((mins as f32) / max_mins).clamp(0.06, 0.48);',
            '                let bx = grid_x + 12.0 + idx as f32 * step_x;',
            '                ui.text(Face::Regular, (9.5 * ui_s).clamp(8.5, 11.0), bx, grid_top + 10.0, color::TEXT, &hrs_lbl);',
            '                let bar_w = (step_x - 8.0).clamp(8.0, 16.0);',
            '                let bh = (row_h * ratio).max(4.0);',
            '                ui.rounded(bx + 2.0, grid_top + 28.0, bar_w, bh, 5.0, color::ACCENT);',
            '                ui.text(Face::Regular, (9.5 * ui_s).clamp(8.5, 11.0), bx, grid_top + row_h - 36.0, color::MUTED, day_lbl);',
            '            }',
            '            ui.text(Face::Medium, (12.5 * ui_s).clamp(10.5, 14.5), grid_x + 14.0, grid_top + row_h - 19.0, color::TEXT, "Play Time (Last 7 Days)");',
            '',
            '            // Card 2 (Top-Right): Mods (.hmod / .jar) & Shaders',
            '            let c2_x = grid_x + col_w + 12.0;',
            '            ui.rounded(c2_x, grid_top, col_w, row_h, 20.0, color::RAISED);',
            '            ui.text(Face::Medium, (14.0 * ui_s).clamp(11.5, 16.0), c2_x + 14.0, grid_top + 12.0, color::TEXT, "Mods & Shaders");',
            '            let c2_main = ui.fit_text(Face::Medium, (13.5 * ui_s).clamp(11.0, 15.5), &format!("{mod_count} Mod · {shader_count} Shader"), col_w - 28.0);',
            '            ui.text(Face::Medium, (13.5 * ui_s).clamp(11.0, 15.5), c2_x + 14.0, grid_top + 34.0, color::ACCENT, &c2_main);',
            '            let c2_sub = ui.fit_text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), "Mendukung .hmod, .jar & Shader", col_w - 28.0);',
            '            ui.text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, grid_top + 56.0, color::MUTED, &c2_sub);',
            '            ui.text(Face::Medium, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, grid_top + row_h - 19.0, color::ACCENT, "Click for more");',
            '            self.targets.push(([c2_x, grid_top, col_w, row_h], Action::Page(Page::Mods)));',
            '',
            '            // Card 3 (Bottom-Left): Today\'s Play Time & Settings Shortcut',
            '            let r2_y = grid_top + row_h + 12.0;',
            '            ui.rounded(grid_x, r2_y, col_w, row_h, 20.0, color::RAISED);',
            '            let today_str = format!("{:.1} h", today_h).replace(\'.\', ",");',
            '            ui.text(Face::Medium, (24.0 * ui_s).clamp(18.0, 28.0), grid_x + col_w * 0.30, r2_y + 16.0, color::TEXT, &today_str);',
            '            ui.text(Face::Regular, (11.5 * ui_s).clamp(9.5, 13.5), grid_x + col_w * 0.38, r2_y + 46.0, color::MUTED, "Today");',
            '            ui.text(Face::Medium, (14.0 * ui_s).clamp(11.5, 16.0), grid_x + col_w * 0.26, r2_y + 66.0, color::ACCENT, "STATISTICS");',
            '            ui.text(Face::Medium, (11.0 * ui_s).clamp(9.5, 13.0), grid_x + 14.0, r2_y + row_h - 19.0, color::ACCENT, "Pengaturan Background & UI");',
            f'            self.targets.push(([grid_x, r2_y, col_w, row_h], {card3_action}));',
            '',
            '            // Card 4 (Bottom-Right): Last Game Log + Download Progress',
            '            ui.rounded(c2_x, r2_y, col_w, row_h, 20.0, color::RAISED);',
            '            ui.text(Face::Medium, (14.0 * ui_s).clamp(11.5, 16.0), c2_x + 14.0, r2_y + 12.0, color::TEXT, if installing { "Download Progress" } else { "Last Game Log" });',
            '            if installing {',
            '                let st_lbl = ui.fit_text(Face::Medium, (12.0 * ui_s).clamp(10.0, 14.0), &format!("{overall_pct}% · {}", progress.stage.label()), col_w - 28.0);',
            '                ui.text(Face::Medium, (12.0 * ui_s).clamp(10.0, 14.0), c2_x + 14.0, r2_y + 36.0, color::ACCENT, &st_lbl);',
            '                let cnt_lbl = ui.fit_text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), &format!("Tahap {}/{} ({}/{})", current_stage + 1, total_stages, progress.done, progress.total), col_w - 28.0);',
            '                ui.text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, r2_y + 56.0, color::MUTED, &cnt_lbl);',
            '                let bar_w_full = (col_w - 28.0).max(40.0);',
            '                ui.rounded(c2_x + 14.0, r2_y + row_h - 24.0, bar_w_full, 6.0, 3.0, 0x26FFFFFF);',
            '                ui.rounded(c2_x + 14.0, r2_y + row_h - 24.0, bar_w_full * overall_frac.max(0.05), 6.0, 3.0, color::ACCENT);',
            '            } else {',
            '                let l1 = ui.fit_text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), "==== Launch Minecraft 26.3 ====", col_w - 28.0);',
            '                let l2 = ui.fit_text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), "▷ Mods: .hmod & .jar Auto-Port", col_w - 28.0);',
            '                let l3 = ui.fit_text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), "▷ Renderer: arm64 · Vulkan", col_w - 28.0);',
            '                ui.text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, r2_y + 34.0, color::MUTED, &l1);',
            '                ui.text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, r2_y + 52.0, color::MUTED, &l2);',
            '                ui.text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, r2_y + 70.0, color::MUTED, &l3);',
            '                ui.text(Face::Medium, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, r2_y + row_h - 19.0, color::ACCENT, "Click for more");',
            '                self.targets.push(([c2_x, r2_y, col_w, row_h], Action::Logs));',
            '            }',
            '',
            '            // Right Tall Profile & Launch Card',
            '            ui.rounded(right_x, 142.0, right_w, grid_h + 10.0, 22.0, color::RAISED);',
            '            let av_size = (54.0 * ui_s).clamp(44.0, 62.0);',
            '            let av_x = right_x + (right_w - av_size) * 0.5;',
            '            let av_y = 160.0;',
            '            ui.rounded(av_x, av_y, av_size, av_size, 8.0, 0xFF6C8EBD);',
            '            ui.rounded(av_x, av_y, av_size, av_size * 0.28, 4.0, 0xFF20304A);',
            '            ui.rounded(av_x + av_size * 0.14, av_y + av_size * 0.46, av_size * 0.21, av_size * 0.12, 1.0, 0xFFFFFFFF);',
            '            ui.rounded(av_x + av_size * 0.25, av_y + av_size * 0.46, av_size * 0.11, av_size * 0.12, 1.0, 0xFF7F3B49);',
            '            ui.rounded(av_x + av_size * 0.64, av_y + av_size * 0.46, av_size * 0.21, av_size * 0.12, 1.0, 0xFFFFFFFF);',
            '            ui.rounded(av_x + av_size * 0.64, av_y + av_size * 0.46, av_size * 0.11, av_size * 0.12, 1.0, 0xFF7F3B49);',
            '            ui.rounded(av_x + av_size * 0.32, av_y + av_size * 0.71, av_size * 0.36, av_size * 0.14, 2.0, 0xFF334778);',
            '',
            '            let player_name = if !self.catalog.config.name.is_empty() {',
            '                self.catalog.config.name.as_str()',
            '            } else {',
            '                ely_user.as_str()',
            '            };',
            '            let name_f = (16.5 * ui_s).clamp(13.5, 19.0);',
            '            let name_w = ui.measure(Face::Medium, name_f, player_name);',
            '            ui.text(Face::Medium, name_f, right_x + ((right_w - name_w) * 0.5).max(12.0), av_y + av_size + 8.0, color::TEXT, player_name);',
            '',
            '            let acc_status = if self.login.signed_in {',
            '                "Microsoft"',
            '            } else if acc_type == "elyby" {',
            '                "Ely.by"',
            '            } else {',
            '                "Offline"',
            '            };',
            '            let st_f = (12.0 * ui_s).clamp(10.0, 13.5);',
            '            let st_w = ui.measure(Face::Regular, st_f, acc_status);',
            '            ui.text(Face::Regular, st_f, right_x + ((right_w - st_w) * 0.5).max(12.0), av_y + av_size + 28.0, color::MUTED, acc_status);',
            '',
            '            let rk_f = (12.0 * ui_s).clamp(10.0, 13.5);',
            '            let rk_w = ui.measure(Face::Medium, rk_f, player_rank);',
            '            ui.text(Face::Medium, rk_f, right_x + ((right_w - rk_w) * 0.5).max(12.0), av_y + av_size + 45.0, color::ACCENT, player_rank);',
            '',
            '            let pt_lbl = format!("Play Time: {:.1} Hours", total_h).replace(\'.\', ",");',
            '            let pt_f = (11.5 * ui_s).clamp(9.5, 13.0);',
            '            let pt_w = ui.measure(Face::Regular, pt_f, &pt_lbl);',
            '            ui.text(Face::Regular, pt_f, right_x + ((right_w - pt_w) * 0.5).max(12.0), av_y + av_size + 62.0, color::MUTED, &pt_lbl);',
            '',
            '            if installing {',
            '                let p_bar_y = 142.0 + grid_h + 10.0 - 116.0;',
            '                let p_bar_w = (right_w - 28.0).max(80.0);',
            '                ui.rounded(right_x + 14.0, p_bar_y, p_bar_w, 6.0, 3.0, 0x26FFFFFF);',
            '                ui.rounded(right_x + 14.0, p_bar_y, p_bar_w * overall_frac.max(0.05), 6.0, 3.0, color::ACCENT);',
            '            }',
            '',
            '            let prof_y = 142.0 + grid_h + 10.0 - 102.0;',
            '            let prof_lbl = ui.fit_text(Face::Medium, (11.5 * ui_s).clamp(9.5, 13.5), &format!("26.3 · UI {:.0}% (#{})", ui_scale_pct, self.catalog.config.profile), right_w - 36.0);',
            '            button(&mut ui, &mut self.targets, [right_x + 14.0, prof_y, right_w - 28.0, 38.0], &prof_lbl, Action::Profile, false);',
            '            let launch_y = 142.0 + grid_h + 10.0 - 56.0;',
            '            let launch_lbl = if installing {',
            '                ui.fit_text(Face::Medium, 12.0, &format!("{overall_pct}% · {}", progress.stage.label()), right_w - 36.0)',
            '            } else if installed {',
            '                "Luncurkan".to_owned()',
            '            } else if self.error.is_some() {',
            '                "Retry Install".to_owned()',
            '            } else {',
            '                "Download 26.3".to_owned()',
            '            };',
            '            button(&mut ui, &mut self.targets, [right_x + 14.0, launch_y, right_w - 28.0, 44.0], &launch_lbl, Action::Play, true);',
        ]
        zalith_plus_play_page = nl.join(play_lines) + nl
        txt = before + zalith_plus_play_page + end_marker + after
    launcher_pages.write_text(txt, encoding="utf-8")
    print("[3/6] Berhasil menerapkan Clean UI Horizon Android di launcher_pages.rs")

# 4. Aktifkan Validasi File .jar (Java Mods) & Custom Background (Gambar & Video) di content_files.rs
cf = pathlib.Path("crates/horizon-client/src/content_files.rs")
if cf.exists():
    txt = cf.read_text(encoding="utf-8")
    bg_exts = ' || lower.ends_with(".png") || lower.ends_with(".jpg") || lower.ends_with(".jpeg") || lower.ends_with(".webp") || lower.ends_with(".mp4") || lower.ends_with(".webm") || lower.ends_with(".gif")'
    txt = txt.replace(
        'Self::Mods => lower.ends_with(".hmod"),',
        f'Self::Mods => lower.ends_with(".hmod") || lower.ends_with(".jar"){bg_exts},',
    )
    txt = txt.replace(
        'Self::Packs | Self::Shaders => lower.ends_with(".zip"),',
        f'Self::Packs | Self::Shaders => lower.ends_with(".zip") || lower.ends_with(".hshader") || lower.ends_with(".jar"){bg_exts},',
    )
    txt = txt.replace(
        'manifest |= raw == "horizon-mod.toml";',
        'manifest |= raw == "horizon-mod.toml" || raw == "fabric.mod.json" || raw == "META-INF/mods.toml" || raw == "META-INF/neoforge.mods.toml" || raw == "pack.mcmeta" || raw.ends_with(".json");',
    )
    cf.write_text(txt, encoding="utf-8")
    print("[4/6] Berhasil mengaktifkan validasi .jar & Custom BG di content_files.rs")

# 5. Patch crates/horizon-client/src/android/documents.rs (100% Compile-Safe, seperti v2.3)
docs = pathlib.Path("crates/horizon-client/src/android/documents.rs")
if docs.exists():
    txt = docs.read_text(encoding="utf-8")
    old_doc_expr = 'format!("{}.hmod", horizon_mods::Package::read(&staged)?.manifest.id)'
    new_doc_expr = (
        '{\n'
        '    let lower_n = name.to_ascii_lowercase();\n'
        '    if lower_n.ends_with(".png") || lower_n.ends_with(".jpg") || lower_n.ends_with(".jpeg") || lower_n.ends_with(".webp") || lower_n.ends_with(".mp4") || lower_n.ends_with(".webm") || lower_n.ends_with(".gif") {\n'
        '        let bg_kind = if lower_n.ends_with(".mp4") || lower_n.ends_with(".webm") || lower_n.ends_with(".gif") { "video" } else { "image" };\n'
        '        if let Some(parent) = staged.parent().and_then(|p| p.parent()) {\n'
        '            let bg_dir = parent.join("backgrounds");\n'
        '            let _ = std::fs::create_dir_all(&bg_dir);\n'
        '            let _ = std::fs::copy(&staged, bg_dir.join(&name));\n'
        '            let raw_b = std::fs::read(&staged).unwrap_or_default();\n'
        '            let mut pal_hex = Vec::new();\n'
        '            let step = (raw_b.len() / 12).max(3);\n'
        '            for idx in 0..6 {\n'
        '                let off = (idx * step + 128) % raw_b.len().max(4);\n'
        '                if off + 2 < raw_b.len() {\n'
        '                    let r = (raw_b[off] as u32).clamp(16, 160);\n'
        '                    let g = (raw_b[off + 1] as u32).clamp(20, 175);\n'
        '                    let b = (raw_b[off + 2] as u32).clamp(28, 210);\n'
        '                    pal_hex.push(format!("{:02X}{:02X}{:02X}", r, g, b));\n'
        '                }\n'
        '            }\n'
        '            let pal_str = if pal_hex.is_empty() { "141E30,243B55,1B2735".to_owned() } else { pal_hex.join(",") };\n'
        '            let htxt_p = parent.join("horizon.txt");\n'
        '            let cur = std::fs::read_to_string(&htxt_p).unwrap_or_default();\n'
        '            let mut lines: Vec<String> = cur.lines().filter(|l| !l.starts_with("zalith_bg_media:") && !l.starts_with("zalith_bg_type:") && !l.starts_with("zalith_bg_palette:")).map(String::from).collect();\n'
        '            lines.push(format!("zalith_bg_media:{name}"));\n'
        '            lines.push(format!("zalith_bg_type:{bg_kind}"));\n'
        '            lines.push(format!("zalith_bg_palette:{pal_str}"));\n'
        '            let _ = std::fs::write(&htxt_p, lines.join("\\n") + "\\n");\n'
        '        }\n'
        '        name.clone()\n'
        '    } else {\n'
        '        format!("{}.hmod", horizon_mods::Package::read(&staged)?.manifest.id)\n'
        '    }\n'
        '}'
    )
    txt = txt.replace(old_doc_expr, new_doc_expr)
    docs.write_text(txt, encoding="utf-8")
    print("[5/6] Berhasil mengaktifkan konverter .jar -> .hmod & Custom BG di documents.rs")

# 6. crates/horizon-mods/src/manifest.rs: Konversi otomatis manifest .jar (fabric.mod.json / mods.toml / pack.mcmeta) menjadi horizon-mod.toml
#    Menggunakan nested match berurutan agar 100% aman dari borrow checker Rust!
mf = pathlib.Path("crates/horizon-mods/src/manifest.rs")
if mf.exists():
    txt = mf.read_text(encoding="utf-8")
    old_read = chr(10).join([
        '            let toml = entry(MANIFEST)?.ok_or_else(|| format!("{MANIFEST}: missing"))?;',
        '            let toml = String::from_utf8(toml).map_err(|_| format!("{MANIFEST}: not UTF-8"))?;',
    ])
    new_read = chr(10).join([
        '            let toml = match entry(MANIFEST)? {',
        '                Some(bytes) => String::from_utf8(bytes).map_err(|_| format!("{MANIFEST}: not UTF-8"))?,',
        '                None => {',
        '                    let fb = match entry("fabric.mod.json")? {',
        '                        Some(b) => Some(b),',
        '                        None => match entry("META-INF/mods.toml")? {',
        '                            Some(b) => Some(b),',
        '                            None => match entry("META-INF/neoforge.mods.toml")? {',
        '                                Some(b) => Some(b),',
        '                                None => entry("pack.mcmeta")?,',
        '                            },',
        '                        },',
        '                    };',
        '                    let nb = fb.ok_or_else(|| format!("{MANIFEST} or fabric.mod.json: missing"))?;',
        '                    let v: serde_json::Value = serde_json::from_slice(&nb).unwrap_or_default();',
        '                    let raw_id = v.get("id").and_then(|x| x.as_str()).unwrap_or("java_mod");',
        '                    let id: String = raw_id.chars().map(|c| if c.is_ascii_alphanumeric() || c == \'_\' { c.to_ascii_lowercase() } else { \'_\' }).collect();',
        '                    let clean_id = if id.is_empty() { "java_mod" } else { id.as_str() };',
        '                    let ver = v.get("version").and_then(|x| x.as_str()).unwrap_or("1.0.0");',
        '                    format!("id = {:?}\\nname = {:?}\\nversion = {:?}\\napi = {:?}\\ncapabilities = [{:?}]\\n", clean_id, format!("{raw_id} (.jar)"), ver, "0.2", "registries")',
        '                }',
        '            };',
    ])
    if old_read in txt:
        txt = txt.replace(old_read, new_read)
    txt = txt.replace(
        'p.extension().is_some_and(|e| e == "hmod")',
        'p.extension().is_some_and(|e| e == "hmod" || e == "jar")',
    )
    mf.write_text(txt, encoding="utf-8")
    print("[6/6] Berhasil mengaktifkan pembacaan manifest mod .jar (Fabric/Forge/NeoForge) di manifest.rs")

ab = pathlib.Path("tools/android_build.py")
if ab.exists():
    txt = ab.read_text(encoding="utf-8")
    old_latest = chr(10).join([
        "def latest(directory):",
        "    return max(directory.iterdir(), key=lambda p: tuple(int(v) for v in p.name.split('.')))",
    ])
    new_latest = chr(10).join([
        "def latest(directory):",
        "    valid = [p for p in directory.iterdir() if p.is_dir() and all(v.isdigit() for v in p.name.split('.'))]",
        "    return max(valid, key=lambda p: tuple(int(v) for v in p.name.split('.')))",
    ])
    if old_latest in txt:
        txt = txt.replace(old_latest, new_latest)
        ab.write_text(txt, encoding="utf-8")
