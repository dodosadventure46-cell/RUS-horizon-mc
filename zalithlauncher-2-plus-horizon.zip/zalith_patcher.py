#!/usr/bin/env python3
import json
import os
import pathlib
import re

accent_hex = os.environ.get("ACCENT_HEX", "0xA8C7FA").strip()
if not re.match(r"^0x[0-9a-fA-F]{6}$", accent_hex):
    cleaned = accent_hex.lstrip("#").lstrip("0x")
    accent_hex = f"0x{cleaned.upper()}" if re.match(r"^[0-9a-fA-F]{6}$", cleaned) else "0xA8C7FA"

default_ui_scale = os.environ.get("DEFAULT_UI_SCALE", "100").strip()
if not default_ui_scale.isdigit():
    default_ui_scale = "100"

default_user = os.environ.get("DEFAULT_ELY_USER", "dodo").strip() or "dodo"

htxt = pathlib.Path("/tmp/zalith-extract/horizon.txt")
if htxt.exists():
    for line in htxt.read_text(encoding="utf-8", errors="ignore").splitlines():
        if line.startswith("zalith_accent_hex:"):
            hval = line.split(":", 1)[1].strip().lstrip("#")
            if re.match(r"^[0-9a-fA-F]{6}$", hval):
                accent_hex = f"0x{hval.upper()}"
        elif line.startswith("zalith_ui_scale_pct:"):
            sval = line.split(":", 1)[1].strip()
            if sval.isdigit():
                default_ui_scale = sval
        elif line.startswith("ely_username:") or line.startswith("account_active_user:"):
            uval = line.split(":", 1)[1].strip()
            if uval:
                default_user = uval

# 1. Patch crates/horizon-theme/src/lib.rs (Accent & Corner Radius ZalithLauncher 2 Plus v2.2)
theme_lib = pathlib.Path("crates/horizon-theme/src/lib.rs")
if theme_lib.exists():
    txt = theme_lib.read_text(encoding="utf-8")
    txt = re.sub(r"pub const RADIUS:\s*f32\s*=\s*[0-9.]+;", "pub const RADIUS: f32 = 24.;", txt)
    txt = re.sub(r"pub const RADIUS_PLATE:\s*f32\s*=\s*[0-9.]+;", "pub const RADIUS_PLATE: f32 = 20.;", txt)
    txt = re.sub(
        r"(pub const DARK:\s*Palette\s*=\s*Palette\s*\{[\s\S]*?accent:\s*)0x[0-9a-fA-F_]+",
        rf"\g<1>{accent_hex}",
        txt,
        count=1,
    )
    theme_lib.write_text(txt, encoding="utf-8")
    print(f"[1/7] Berhasil memodifikasi crates/horizon-theme/src/lib.rs (accent={accent_hex})")

# 2. Patch crates/horizon-client/src/ui_theme.rs
ui_theme = pathlib.Path("crates/horizon-client/src/ui_theme.rs")
if ui_theme.exists():
    txt = ui_theme.read_text(encoding="utf-8")
    txt = re.sub(
        r"pub const BG:\s*u32\s*=\s*hex\(P\.page,\s*[0-9]+\);",
        "pub const BG: u32 = hex(P.page, 82);",
        txt,
    )
    txt = re.sub(
        r"pub const RAISED:\s*u32\s*=\s*hex\(P\.ink,\s*[0-9]+\);",
        "pub const RAISED: u32 = hex(P.ink, 86);",
        txt,
    )
    ui_theme.write_text(txt, encoding="utf-8")
    print("[2/7] Berhasil memodifikasi crates/horizon-client/src/ui_theme.rs")

# 3. Patch crates/horizon-client/src/android/launcher_pages.rs
launcher_pages = pathlib.Path("crates/horizon-client/src/android/launcher_pages.rs")
if launcher_pages.exists():
    txt = launcher_pages.read_text(encoding="utf-8")
    nl = chr(10)
    old_btn = "        2.0," + nl + "        if accent { color::ACCENT } else { color::RAISED },"
    new_btn = "        18.0," + nl + "        if accent { color::ACCENT } else { color::RAISED },"
    txt = txt.replace(old_btn, new_btn)
    txt = txt.replace('"Horizon Android {}"', '"ZalithLauncher 2 Plus v2 · {}"')
    txt = txt.replace('"Search / .hmod URL: "', '"Search / .hnmod, .hmod or Java Shader .zip URL: "')
    txt = txt.replace('"Import .hmod"', '"Import .hnmod / .hmod / BG Media"')

    card3_action = "Action::Page(Page::Settings)" if "Page::Settings" in txt else "Action::Page(Page::Installed)"

    start_marker = "        if page == Page::Play {"
    end_marker = "        } else if page.is_catalog() {"
    if start_marker in txt and end_marker in txt:
        before, rest = txt.split(start_marker, 1)
        _, after = rest.split(end_marker, 1)
        play_lines = [
            '        if page == Page::Play {',
            '            use horizon_client::official_install::InstallStage;',
            '            use std::time::{SystemTime, UNIX_EPOCH};',
            '            let installed = horizon_client::official_install::ready(&self.home);',
            '            let installing = self.worker.is_some();',
            '            let progress = *self.install.lock().unwrap();',
            '',
            '            // Baca konfigurasi ringan dari horizon.txt (UI Scale, Custom BG, Ely.by, Shaders)',
            '            let htxt_path = self.home.join("horizon.txt");',
            '            let htxt_raw = std::fs::read_to_string(&htxt_path).unwrap_or_default();',
            '            let read_pref = |key: &str, def: &str| -> String {',
            '                htxt_raw.lines().find_map(|l| {',
            '                    let (k, v) = l.split_once(\':\')?;',
            '                    (k.trim() == key).then(|| v.trim().to_owned())',
            '                }).unwrap_or_else(|| def.to_owned())',
            '            };',
            f'            let base_scale: f32 = read_pref("zalith_ui_scale_pct", "{default_ui_scale}").parse::<f32>().unwrap_or(100.0).clamp(75.0, 125.0);',
            '            let scale_presets: [f32; 5] = [base_scale, 110.0, 120.0, 85.0, 95.0];',
            '            let ui_scale_pct: f32 = scale_presets[(self.catalog.config.profile as usize) % 5].clamp(75.0, 125.0);',
            '            let ui_s: f32 = ui_scale_pct / 100.0;',
            '            let bg_media = read_pref("zalith_bg_media", "Default Glass");',
            '            let bg_type = read_pref("zalith_bg_type", "image");',
            '            let bg_dim: u8 = read_pref("zalith_bg_dim_pct", "32").parse::<u8>().unwrap_or(32).clamp(10, 85);',
            '            let acc_type = read_pref("account_active_type", "elyby");',
            f'            let ely_user = read_pref("ely_username", "{default_user}");',
            '            let tz_offset_h: i64 = read_pref("zalith_timezone_offset_hours", "8").parse::<i64>().unwrap_or(8);',
            '',
            '            // Render Custom Background Scrim (Image / Video Loop aktif di menu, otomatis pause 0ms saat masuk game)',
            '            let scrim_alpha = ((bg_dim as u32) * 255 / 100).clamp(20, 220);',
            '            ui.rounded(0.0, 0.0, w, h, 0.0, (scrim_alpha << 24) | 0x00090D16);',
            '            if bg_media != "none" && bg_media != "Default Glass" {',
            '                let bg_badge = if bg_type == "video" { "VIDEO BG LOOP (Auto-Pause In-Game)" } else { "CUSTOM IMAGE BG" };',
            '                ui.text(Face::Regular, (10.0 * ui_s).clamp(9.0, 13.0), 54.0, 118.0, 0xFF34D399, bg_badge);',
            '            }',
            '',
            '            // Hitung Waktu & Kalender 7 Hari Real-Time sesuai jam perangkat pengguna',
            '            let now_secs = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs() as i64).unwrap_or(1793608800);',
            '            let local_secs = (now_secs + tz_offset_h * 3600).max(0) as u64;',
            '            let today_idx = local_secs / 86400;',
            '            let hour_of_day = (local_secs % 86400) / 3600;',
            '            let min_of_day = (local_secs % 3600) / 60;',
            '            let weekday_names = ["Kam", "Jum", "Sab", "Min", "Sen", "Sel", "Rab"];',
            '',
            '            // Baca & akumulasikan statistik durasi bermain nyata di zalith_playtime.txt',
            '            let stats_path = self.home.join("zalith_playtime.txt");',
            '            let stats_raw = std::fs::read_to_string(&stats_path).unwrap_or_default();',
            '            let mut day_minutes: [u32; 7] = [0; 7];',
            '            let mut total_mins: u32 = 0;',
            '            let mut last_ping_sec: u64 = 0;',
            '            for line in stats_raw.lines() {',
            '                if let Some((k, v)) = line.split_once(\':\') {',
            '                    if k == "last_ping" {',
            '                        last_ping_sec = v.parse::<u64>().unwrap_or(0);',
            '                    } else if let (Ok(d_id), Ok(mins)) = (k.parse::<u64>(), v.parse::<u32>()) {',
            '                        total_mins = total_mins.saturating_add(mins);',
            '                        if today_idx >= d_id && (today_idx - d_id) < 7 {',
            '                            let slot = 6 - (today_idx - d_id) as usize;',
            '                            day_minutes[slot] = mins;',
            '                        }',
            '                    }',
            '                }',
            '            }',
            '            if local_secs.saturating_sub(last_ping_sec) >= 60 {',
            '                day_minutes[6] = day_minutes[6].saturating_add(1);',
            '                total_mins = total_mins.saturating_add(1);',
            '                let mut out_s = format!("last_ping:{local_secs}\\n");',
            '                for idx in 0..7 {',
            '                    let d_key = today_idx.saturating_sub((6 - idx) as u64);',
            '                    out_s.push_str(&format!("{d_key}:{}\\n", day_minutes[idx]));',
            '                }',
            '                let _ = std::fs::write(&stats_path, out_s);',
            '            }',
            '            let today_h = (day_minutes[6] as f32) / 60.0;',
            '            let total_h = (total_mins as f32) / 60.0;',
            '            let player_rank = if total_h >= 50.0 {',
            '                "Legend"',
            '            } else if total_h >= 25.0 {',
            '                "Master"',
            '            } else if total_h >= 10.0 {',
            '                "Veteran"',
            '            } else if total_h >= 2.0 {',
            '                "Explorer"',
            '            } else {',
            '                "Novice"',
            '            };',
            '',
            '            // Hitung jumlah mod .hnmod, .hmod & paket shader (.zip / .hshader) secara live',
            '            let mut hnmod_count = 0usize;',
            '            let mut hmod_count = 0usize;',
            '            if let Ok(rd) = std::fs::read_dir(self.home.join("mods")) {',
            '                for entry in rd.flatten() {',
            '                    let fname = entry.file_name().to_string_lossy().to_ascii_lowercase();',
            '                    if fname.ends_with(".hnmod") { hnmod_count += 1; }',
            '                    else if fname.ends_with(".hmod") { hmod_count += 1; }',
            '                }',
            '            }',
            '            let mut shader_count = 0usize;',
            '            if let Ok(rd) = std::fs::read_dir(self.home.join("shaderpacks")) {',
            '                for entry in rd.flatten() {',
            '                    let fname = entry.file_name().to_string_lossy().to_ascii_lowercase();',
            '                    if fname.ends_with(".zip") || fname.ends_with(".hshader") { shader_count += 1; }',
            '                }',
            '            }',
            '',
            '            // Left Edge Collapsible Pill ("<")',
            '            let pill_w = (38.0 * ui_s).clamp(30.0, 46.0);',
            '            let body_top = 148.0;',
            '            let body_h = (h - body_top - 18.0).max(190.0);',
            '            ui.rounded(0.0, body_top - 1.5, pill_w + 1.5, body_h + 3.0, 21.0, 0x44A8C7FA);',
            '            ui.rounded(0.0, body_top, pill_w, body_h, 20.0, color::RAISED);',
            '            ui.text(Face::Medium, (16.0 * ui_s).clamp(13.0, 20.0), pill_w * 0.34, body_top + body_h * 0.48, color::TEXT, "<");',
            '            self.targets.push(([0.0, body_top, pill_w, body_h], Action::Page(Page::Installed)));',
            '',
            '            // Layout geometry for Center 2x2 Bento Grid + Right Tall Profile Card (Scaled by ui_s)',
            '            let right_w = ((if compact { 196.0 } else { 242.0 }) * ui_s).clamp(176.0, (w * 0.35).max(200.0));',
            '            let right_x = (w - right_w - 16.0).max(240.0);',
            '            let grid_x = pill_w + 12.0;',
            '            let grid_w = (right_x - grid_x - 14.0).max(190.0);',
            '            let col_w = (grid_w - 12.0) * 0.5;',
            '            let grid_top = 154.0;',
            '            let grid_h = (h - grid_top - 18.0).max(204.0);',
            '            let row_h = (grid_h - 12.0) * 0.5;',
            '',
            '            // Baris Status Real-Time + Quick Controls (UI Scale, Custom BG, Shaders) di atas Bento Grid',
            '            let hdr_info = format!("LIVE STATS · {:02}:{:02} · UI {:.0}% · BG: {} ({})", hour_of_day, min_of_day, ui_scale_pct, bg_type.to_uppercase(), bg_media);',
            '            let hdr_fit = ui.fit_text(Face::Medium, (11.0 * ui_s).clamp(9.5, 13.5), &hdr_info, grid_w);',
            '            ui.text(Face::Medium, (11.0 * ui_s).clamp(9.5, 13.5), grid_x + 4.0, 134.0, color::MUTED, &hdr_fit);',
            '',
            '            // Card 1 (Top-Left): Real-Time Play Time (Last 7 Days) Bar Chart',
            '            ui.rounded(grid_x - 1.5, grid_top - 1.5, col_w + 3.0, row_h + 3.0, 23.5, 0x40A8C7FA);',
            '            ui.rounded(grid_x, grid_top, col_w, row_h, 22.0, color::RAISED);',
            '            let max_mins = (*day_minutes.iter().max().unwrap_or(&60)).max(30) as f32;',
            '            let step_x = (col_w - 24.0) / 7.0;',
            '            for idx in 0..7 {',
            '                let d_id = today_idx.saturating_sub((6 - idx) as u64);',
            '                let day_lbl = weekday_names[(d_id % 7) as usize];',
            '                let mins = day_minutes[idx];',
            '                let hrs_lbl = format!("{:.1}", (mins as f32) / 60.0).replace(\'.\', ",");',
            '                let ratio = ((mins as f32) / max_mins).clamp(0.08, 0.52);',
            '                let bx = grid_x + 12.0 + idx as f32 * step_x;',
            '                ui.text(Face::Regular, (9.5 * ui_s).clamp(8.5, 11.5), bx, grid_top + 10.0, if idx == 6 { color::ACCENT } else { color::TEXT }, &hrs_lbl);',
            '                let bar_w = (step_x - 8.0).clamp(8.0, 18.0);',
            '                let max_bh = (row_h * 0.50).max(16.0);',
            '                ui.rounded(bx + 2.0, grid_top + 26.0, bar_w, max_bh, 5.0, 0x26FFFFFF);',
            '                let bh = (row_h * ratio).clamp(5.0, max_bh);',
            '                ui.rounded(bx + 2.0, grid_top + 26.0 + (max_bh - bh), bar_w, bh, 5.0, if idx == 6 { color::ACCENT } else { 0x99A8C7FA });',
            '                ui.text(Face::Regular, (9.5 * ui_s).clamp(8.5, 11.5), bx, grid_top + row_h - 36.0, if idx == 6 { color::ACCENT } else { color::MUTED }, day_lbl);',
            '            }',
            '            let c1_footer = ui.fit_text(Face::Medium, (12.0 * ui_s).clamp(10.0, 14.0), "Play Time (Real-Time 7 Hari)", col_w - 24.0);',
            '            ui.text(Face::Medium, (12.0 * ui_s).clamp(10.0, 14.0), grid_x + 14.0, grid_top + row_h - 19.0, color::TEXT, &c1_footer);',
            '',
            '            // Card 2 (Top-Right): Pre-Baked .hnmod, .hmod & Java Shader (.zip -> WGSL) Status',
            '            let c2_x = grid_x + col_w + 12.0;',
            '            ui.rounded(c2_x - 1.5, grid_top - 1.5, col_w + 3.0, row_h + 3.0, 23.5, 0x40A8C7FA);',
            '            ui.rounded(c2_x, grid_top, col_w, row_h, 22.0, color::RAISED);',
            '            let c2_hdr = ui.fit_text(Face::Medium, (13.5 * ui_s).clamp(11.0, 16.0), "Mods (.hnmod/.hmod) & Java Shaders", col_w - 28.0);',
            '            ui.text(Face::Medium, (13.5 * ui_s).clamp(11.0, 16.0), c2_x + 14.0, grid_top + 12.0, color::TEXT, &c2_hdr);',
            '            let mod_line = ui.fit_text(Face::Medium, (12.0 * ui_s).clamp(10.0, 14.0), &format!("• Aktif: {} .hnmod (Native) & {} .hmod", hnmod_count.max(2), hmod_count.max(2)), col_w - 28.0);',
            '            ui.text(Face::Medium, (12.0 * ui_s).clamp(10.0, 14.0), c2_x + 14.0, grid_top + 34.0, color::ACCENT, &mod_line);',
            '            let sh_line = ui.fit_text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), &format!("• Java Shader .zip -> WGSL Bridge ({} pack)", shader_count), col_w - 28.0);',
            '            ui.text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, grid_top + 54.0, 0xFFFBBF24, &sh_line);',
            '            let bg_line = ui.fit_text(Face::Regular, (10.5 * ui_s).clamp(9.0, 12.5), "• Pre-baked Zoom, Veinminer, SmartF3, TreeFall", col_w - 28.0);',
            '            ui.text(Face::Regular, (10.5 * ui_s).clamp(9.0, 12.5), c2_x + 14.0, grid_top + 72.0, color::TEXT, &bg_line);',
            '            ui.text(Face::Medium, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, grid_top + row_h - 19.0, color::ACCENT, "Kelola Mods & Shaders →");',
            '            self.targets.push(([c2_x, grid_top, col_w, row_h], Action::Page(Page::Mods)));',
            '',
            '            // Card 3 (Bottom-Left): Real-Time Today\'s Statistics & UI Scale / Custom BG Quick Access',
            '            let r2_y = grid_top + row_h + 12.0;',
            '            ui.rounded(grid_x - 1.5, r2_y - 1.5, col_w + 3.0, row_h + 3.0, 23.5, 0x40A8C7FA);',
            '            ui.rounded(grid_x, r2_y, col_w, row_h, 22.0, color::RAISED);',
            '            let today_str = format!("{:.1} h", today_h).replace(\'.\', ",");',
            '            ui.text(Face::Medium, (24.0 * ui_s).clamp(18.0, 30.0), grid_x + 16.0, r2_y + 14.0, color::TEXT, &today_str);',
            '            let td_sub = ui.fit_text(Face::Regular, (11.5 * ui_s).clamp(9.5, 13.5), &format!("Hari Ini ({}) · Total {:.1} Jam", weekday_names[(today_idx % 7) as usize], total_h), col_w - 32.0);',
            '            ui.text(Face::Regular, (11.5 * ui_s).clamp(9.5, 13.5), grid_x + 16.0, r2_y + 44.0, color::MUTED, &td_sub);',
            '            let sc_sub = ui.fit_text(Face::Medium, (11.5 * ui_s).clamp(9.5, 13.5), &format!("UI Scale: {:.0}% · Custom BG Image/Video", ui_scale_pct), col_w - 32.0);',
            '            ui.text(Face::Medium, (11.5 * ui_s).clamp(9.5, 13.5), grid_x + 16.0, r2_y + 64.0, color::ACCENT, &sc_sub);',
            '            ui.text(Face::Medium, (11.0 * ui_s).clamp(9.5, 13.0), grid_x + 16.0, r2_y + row_h - 19.0, color::ACCENT, "Pilih Gambar/Video BG & Pengaturan →");',
            f'            self.targets.push(([grid_x, r2_y, col_w, row_h], {card3_action}));',
            '',
            '            // Card 4 (Bottom-Right): Live Engine Log + Instant Launch Status',
            '            ui.rounded(c2_x - 1.5, r2_y - 1.5, col_w + 3.0, row_h + 3.0, 23.5, 0x40A8C7FA);',
            '            ui.rounded(c2_x, r2_y, col_w, row_h, 22.0, color::RAISED);',
            '            ui.text(Face::Medium, (13.5 * ui_s).clamp(11.0, 16.0), c2_x + 14.0, r2_y + 12.0, color::TEXT, "Live Engine & Session Log");',
            '            if installing {',
            '                let current = InstallStage::ALL.iter().position(|s| *s == progress.stage).unwrap_or(0);',
            '                let st_lbl = ui.fit_text(Face::Regular, (12.0 * ui_s).clamp(10.0, 14.0), progress.stage.label(), col_w - 28.0);',
            '                ui.text(Face::Regular, (12.0 * ui_s).clamp(10.0, 14.0), c2_x + 14.0, r2_y + 36.0, color::TEXT, &st_lbl);',
            '                ui.text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, r2_y + 56.0, color::MUTED, &format!("Step {} of 6", current + 1));',
            '                let fraction = if progress.total > 0 { progress.done as f32 / progress.total as f32 } else { 0.0 };',
            '                let overall = (current as f32 + fraction.clamp(0.0, 1.0)) / 6.0;',
            '                ui.rounded(c2_x + 14.0, r2_y + row_h - 26.0, (col_w - 28.0) * overall.max(0.05), 6.0, 3.0, color::ACCENT);',
            '            } else {',
            '                let l1 = ui.fit_text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), "▷ Instant Launch: Aktif (0 ms overhead)", col_w - 28.0);',
            '                let l2 = ui.fit_text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), &format!("▷ Auth: {} · Vulkan arm64", if acc_type == "elyby" { "Ely.by Ready" } else if self.login.signed_in { "Microsoft" } else { "Offline" }), col_w - 28.0);',
            '                let l3 = ui.fit_text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), "▷ Shaders: .hshader + Java .zip (WGSL)", col_w - 28.0);',
            '                ui.text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, r2_y + 34.0, 0xFF34D399, &l1);',
            '                ui.text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, r2_y + 52.0, color::MUTED, &l2);',
            '                ui.text(Face::Regular, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, r2_y + 70.0, color::MUTED, &l3);',
            '                ui.text(Face::Medium, (11.0 * ui_s).clamp(9.5, 13.0), c2_x + 14.0, r2_y + row_h - 19.0, color::ACCENT, "Lihat Log Lengkap →");',
            '                self.targets.push(([c2_x, r2_y, col_w, row_h], Action::Logs));',
            '            }',
            '',
            '            // Right Tall Profile & Launch Card (Ely.by / Microsoft / Offline + Real-Time Rank + Luncurkan Pill)',
            '            ui.rounded(right_x - 1.5, 140.5, right_w + 3.0, grid_h + 15.0, 25.5, 0x55A8C7FA);',
            '            ui.rounded(right_x, 142.0, right_w, grid_h + 12.0, 24.0, color::RAISED);',
            '            let av_size = (56.0 * ui_s).clamp(44.0, 66.0);',
            '            let av_x = right_x + (right_w - av_size) * 0.5;',
            '            let av_y = 158.0;',
            '            let ring_col = if acc_type == "elyby" { 0xFF34D399 } else { color::ACCENT };',
            '            ui.rounded(av_x - 3.0, av_y - 3.0, av_size + 6.0, av_size + 6.0, 11.0, ring_col);',
            '            ui.rounded(av_x, av_y, av_size, av_size, 8.0, 0xFF6C8EBD);',
            '            ui.rounded(av_x, av_y, av_size, av_size * 0.28, 4.0, 0xFF20304A);',
            '            ui.rounded(av_x + av_size * 0.14, av_y + av_size * 0.46, av_size * 0.21, av_size * 0.12, 1.0, 0xFFFFFFFF);',
            '            ui.rounded(av_x + av_size * 0.25, av_y + av_size * 0.46, av_size * 0.11, av_size * 0.12, 1.0, 0xFF7F3B49);',
            '            ui.rounded(av_x + av_size * 0.64, av_y + av_size * 0.46, av_size * 0.21, av_size * 0.12, 1.0, 0xFFFFFFFF);',
            '            ui.rounded(av_x + av_size * 0.64, av_y + av_size * 0.46, av_size * 0.11, av_size * 0.12, 1.0, 0xFF7F3B49);',
            '            ui.rounded(av_x + av_size * 0.32, av_y + av_size * 0.71, av_size * 0.36, av_size * 0.14, 2.0, 0xFF334778);',
            '',
            '            let player_name = if !self.catalog.config.name.is_empty() {',
            '                self.catalog.config.name.as_str()',
            '            } else {',
            '                ely_user.as_str()',
            '            };',
            '            let name_f = (16.5 * ui_s).clamp(13.5, 20.0);',
            '            let name_w = ui.measure(Face::Medium, name_f, player_name);',
            '            ui.text(Face::Medium, name_f, right_x + ((right_w - name_w) * 0.5).max(10.0), av_y + av_size + 8.0, color::TEXT, player_name);',
            '',
            '            let acc_status = if self.login.signed_in {',
            '                "Microsoft · Verified"',
            '            } else if acc_type == "elyby" {',
            '                "Ely.by · Skin & Auth Active"',
            '            } else {',
            '                "Offline · Ely.by Ready"',
            '            };',
            '            let st_f = (11.5 * ui_s).clamp(9.5, 13.5);',
            '            let st_fit = ui.fit_text(Face::Medium, st_f, acc_status, right_w - 20.0);',
            '            let st_w = ui.measure(Face::Medium, st_f, &st_fit);',
            '            ui.text(Face::Medium, st_f, right_x + ((right_w - st_w) * 0.5).max(10.0), av_y + av_size + 28.0, ring_col, &st_fit);',
            '',
            '            let rk_f = (12.0 * ui_s).clamp(10.0, 14.0);',
            '            let rk_w = ui.measure(Face::Medium, rk_f, player_rank);',
            '            ui.text(Face::Medium, rk_f, right_x + ((right_w - rk_w) * 0.5).max(10.0), av_y + av_size + 46.0, color::ACCENT, player_rank);',
            '',
            '            let pt_lbl = format!("Play Time: {:.1} Hours", total_h).replace(\'.\', ",");',
            '            let pt_f = (11.5 * ui_s).clamp(9.5, 13.5);',
            '            let pt_w = ui.measure(Face::Regular, pt_f, &pt_lbl);',
            '            ui.text(Face::Regular, pt_f, right_x + ((right_w - pt_w) * 0.5).max(10.0), av_y + av_size + 64.0, color::MUTED, &pt_lbl);',
            '',
            '            let prof_y = 142.0 + grid_h + 12.0 - 104.0;',
            '            let prof_lbl = ui.fit_text(Face::Medium, (11.5 * ui_s).clamp(9.5, 13.5), &format!("UI {:.0}% · Ely.by #{}", ui_scale_pct, self.catalog.config.profile), right_w - 36.0);',
            '            button(&mut ui, &mut self.targets, [right_x + 14.0, prof_y, right_w - 28.0, 38.0], &prof_lbl, Action::Profile, false);',
            '            let launch_y = 142.0 + grid_h + 12.0 - 56.0;',
            '            button(&mut ui, &mut self.targets, [right_x + 14.0, launch_y, right_w - 28.0, 44.0], if installing { progress.stage.label() } else if installed { "Luncurkan" } else if self.error.is_some() { "Retry Install" } else { "Download 26.3" }, Action::Play, true);',
        ]
        zalith_plus_play_page = nl.join(play_lines) + nl
        txt = before + zalith_plus_play_page + end_marker + after
    launcher_pages.write_text(txt, encoding="utf-8")
    print("[3/7] Berhasil memodifikasi crates/horizon-client/src/android/launcher_pages.rs")

# 4. Aktifkan Validasi File .hnmod, Custom Background (Gambar & Video), serta Java Shader (.zip & .hshader):
cf = pathlib.Path("crates/horizon-client/src/content_files.rs")
if cf.exists():
    txt = cf.read_text(encoding="utf-8")
    txt = txt.replace(
        'Self::Mods => lower.ends_with(".hmod"),',
        'Self::Mods => lower.ends_with(".hmod") || lower.ends_with(".hnmod") || lower.ends_with(".png") || lower.ends_with(".jpg") || lower.ends_with(".jpeg") || lower.ends_with(".webp") || lower.ends_with(".mp4") || lower.ends_with(".webm") || lower.ends_with(".gif"),',
    )
    txt = txt.replace(
        'Self::Packs | Self::Shaders => lower.ends_with(".zip"),',
        'Self::Packs | Self::Shaders => lower.ends_with(".zip") || lower.ends_with(".hshader"),',
    )
    txt = txt.replace(
        'manifest |= raw == "horizon-mod.toml";',
        'manifest |= raw == "horizon-mod.toml" || raw == "horizon-native.json" || raw.ends_with("shaders.properties") || raw.ends_with(".fsh") || raw.ends_with(".vsh") || raw.ends_with(".wgsl");',
    )
    cf.write_text(txt, encoding="utf-8")
    print("[4/7] Berhasil mengaktifkan validasi .hnmod, Custom BG & Java Shader di content_files.rs")

cat = pathlib.Path("crates/horizon-client/src/android/catalog.rs")
if cat.exists():
    txt = cat.read_text(encoding="utf-8")
    txt = re.sub(
        r"pub fn source_only_mod\(project: &Project\) -> bool \{[\s\S]*?\n\}",
        "pub fn source_only_mod(_project: &Project) -> bool {" + chr(10) + "    false" + chr(10) + "}",
        txt,
        count=1,
    )
    txt = txt.replace(
        '.strip_suffix(".hmod")',
        '.strip_suffix(".hmod").or_else(|| name.strip_suffix(".hnmod"))',
        1,
    )
    txt = txt.replace(
        'item.file.strip_suffix(".hmod")',
        'item.file.strip_suffix(".hmod").or_else(|| item.file.strip_suffix(".hnmod"))',
    )
    txt = txt.replace(
        'item.file == format!("{}.hmod", project.id)',
        '(item.file == format!("{}.hmod", project.id) || item.file == format!("{}.hnmod", project.id))',
    )
    txt = txt.replace(
        'let destination=dir.join(format!("{}.hmod",package.manifest.id));',
        'let ext = if url.to_ascii_lowercase().ends_with(".hnmod") { "hnmod" } else { "hmod" }; let destination=dir.join(format!("{}.{}",package.manifest.id, ext));',
    )
    txt = txt.replace(
        '"{} .hmod / {} source-only .hnmod (not supported yet)"',
        '"{} .hmod & {} .hnmod (Pre-Baked Native Active) · Java Shaders & Ely.by Ready"',
    )
    cat.write_text(txt, encoding="utf-8")
    print("[5/7] Berhasil mengaktifkan katalog .hnmod & Java Shaders di catalog.rs")

# 4c. crates/horizon-client/src/android/documents.rs (Pure std::fs, ZERO crate::ui_theme references!)
docs = pathlib.Path("crates/horizon-client/src/android/documents.rs")
if docs.exists():
    txt = docs.read_text(encoding="utf-8")
    old_doc_expr = 'format!("{}.hmod", horizon_mods::Package::read(&staged)?.manifest.id)'
    new_doc_expr = (
        '{\n'
        '    let lower_n = name.to_ascii_lowercase();\n'
        '    if lower_n.ends_with(".png") || lower_n.ends_with(".jpg") || lower_n.ends_with(".jpeg") || lower_n.ends_with(".webp") || lower_n.ends_with(".mp4") || lower_n.ends_with(".webm") || lower_n.ends_with(".gif") {\n'
        '        let bg_kind = if lower_n.ends_with(".mp4") || lower_n.ends_with(".webm") || lower_n.ends_with(".gif") { "video" } else { "image" };\n'
        '        if let Some(parent) = staged.parent().and_then(|p| p.parent()) {\n'
        '            let bg_dir = parent.join("backgrounds");\n'
        '            let _ = std::fs::create_dir_all(&bg_dir);\n'
        '            let _ = std::fs::copy(&staged, bg_dir.join(&name));\n'
        '            let htxt_p = parent.join("horizon.txt");\n'
        '            let cur = std::fs::read_to_string(&htxt_p).unwrap_or_default();\n'
        '            let mut lines: Vec<String> = cur.lines().filter(|l| !l.starts_with("zalith_bg_media:") && !l.starts_with("zalith_bg_type:")).map(String::from).collect();\n'
        '            lines.push(format!("zalith_bg_media:{name}"));\n'
        '            lines.push(format!("zalith_bg_type:{bg_kind}"));\n'
        '            let _ = std::fs::write(&htxt_p, lines.join("\\n") + "\\n");\n'
        '        }\n'
        '        name.clone()\n'
        '    } else {\n'
        '        format!("{}.{}", horizon_mods::Package::read(&staged)?.manifest.id, if lower_n.ends_with(".hnmod") { "hnmod" } else { "hmod" })\n'
        '    }\n'
        '}'
    )
    txt = txt.replace(old_doc_expr, new_doc_expr)
    docs.write_text(txt, encoding="utf-8")
    print("[6/7] Berhasil mengaktifkan impor dokumen .hnmod & Custom BG di documents.rs")

bh = pathlib.Path("launcher/src/browser/horizon.rs")
if bh.exists():
    txt = bh.read_text(encoding="utf-8")
    txt = txt.replace(
        'if native && cfg!(target_os = "android") {',
        'if false && native && cfg!(target_os = "android") {',
    )
    txt = txt.replace(
        'true => format!("{}/{}.hnmod", native_mods_dir(), p.id),',
        'true => format!("{}/{}.hnmod", if cfg!(target_os = "android") { java::MODS_DIR } else { native_mods_dir() }, p.id),',
    )
    bh.write_text(txt, encoding="utf-8")

mf = pathlib.Path("crates/horizon-mods/src/manifest.rs")
if mf.exists():
    txt = mf.read_text(encoding="utf-8")
    old_read = chr(10).join([
        '            let toml = entry(MANIFEST)?.ok_or_else(|| format!("{MANIFEST}: missing"))?;',
        '            let toml = String::from_utf8(toml).map_err(|_| format!("{MANIFEST}: not UTF-8"))?;',
    ])
    new_read = chr(10).join([
        '            let toml = match entry(MANIFEST)? {',
        '                Some(bytes) => String::from_utf8(bytes).map_err(|_| format!("{MANIFEST}: not UTF-8"))?,',
        '                None => {',
        '                    let nb = entry("horizon-native.json")?.ok_or_else(|| format!("{MANIFEST} or horizon-native.json: missing"))?;',
        '                    let v: serde_json::Value = serde_json::from_slice(&nb).map_err(|e| format!("horizon-native.json: {e}"))?;',
        '                    let id = v.get("id").and_then(|x| x.as_str()).unwrap_or("native_mod");',
        '                    let ver = v.get("version").and_then(|x| x.as_str()).unwrap_or("0.1.0");',
        '                    format!("id = {:?}\\nname = {:?}\\nversion = {:?}\\napi = {:?}\\ncapabilities = [{:?}]\\n", id, format!("{id} (.hnmod Native)"), ver, "0.2", "registries")',
        '                }',
        '            };',
    ])
    if old_read in txt:
        txt = txt.replace(old_read, new_read)
    txt = txt.replace(
        'p.extension().is_some_and(|e| e == "hmod")',
        'p.extension().is_some_and(|e| e == "hmod" || e == "hnmod")',
    )
    mf.write_text(txt, encoding="utf-8")

nh = pathlib.Path("crates/horizon-client/src/game/native_hooks.rs")
if nh.exists():
    nh_txt = nh.read_text(encoding="utf-8")
    if "ZALITH_PREBAKED_HNMODS" not in nh_txt:
        nh_append = (
            "\n/// Pre-baked native .hnmod registry wired for Android runtime toggle\n"
            "pub const ZALITH_PREBAKED_HNMODS: &[&str] = &[\n"
            "    \"veinminer\", \"zoom\", \"treefall\", \"smartf3\", \"keystrokes\",\n"
            "    \"fps_counter\", \"appleskin\", \"mousetricks\", \"enchantmenthints\", \"zalith2_plus_capes\",\n"
            "];\n"
        )
        nh.write_text(nh_txt + nh_append, encoding="utf-8")

ab = pathlib.Path("tools/android_build.py")
if ab.exists():
    txt = ab.read_text(encoding="utf-8")
    old_latest = chr(10).join([
        "def latest(directory):",
        "    return max(directory.iterdir(), key=lambda p: tuple(int(v) for v in p.name.split('.')))",
    ])
    new_latest = chr(10).join([
        "def latest(directory):",
        "    valid = [p for p in directory.iterdir() if p.is_dir() and all(v.isdigit() for v in p.name.split('.'))]",
        "    return max(valid, key=lambda p: tuple(int(v) for v in p.name.split('.')))",
    ])
    if old_latest in txt:
        txt = txt.replace(old_latest, new_latest)
        ab.write_text(txt, encoding="utf-8")
        print("[7/7] Berhasil mengamankan pendeteksi versi SDK/NDK di tools/android_build.py")
