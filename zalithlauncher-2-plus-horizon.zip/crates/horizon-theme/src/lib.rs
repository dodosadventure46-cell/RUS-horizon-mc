//! Horizon's design tokens — Modified for ZalithLauncher 2 Plus UI Overhaul
//! Repository Target: https://github.com/Vasysik/horizon-android (branch: android)
//! Engine functionality remains 100% identical; adds .hnmod support & Zalith 2 Plus UI.

pub const FONT: &str = "Bricolage Grotesque";
pub const BODY_FONT: &str = "Plus Jakarta Sans";
pub const MONO: &str = "JetBrains Mono";
pub const PIXEL: &str = "Pixelify Sans";

/// Corner radius in logical pixels (dp) tuned to ZalithLauncher 2 Plus ergonomics
pub const RADIUS: f32 = 24.0;
pub const RADIUS_PLATE: f32 = 20.0;

pub struct Palette {
    pub page: u32,
    pub plate: u32,
    pub plate_soft: u32,
    pub rule: u32,
    pub ink: u32,
    pub ink_soft: u32,
    pub accent: u32,
    pub on_accent: u32,
}

/// ZalithLauncher 2 Plus Frosted Glass Palette (Zalith 2 Plus Pastel — #A8C7FA)
pub const DARK: Palette = Palette {
    page: 0x0B0F17,
    plate: 0x111827,
    plate_soft: 0x1E293B,
    rule: 0x334155,
    ink: 0xF8FAFC,
    ink_soft: 0x94A3B8,
    accent: 0xA8C7FA,
    on_accent: 0x0F172A,
};

pub struct TypeScale {
    pub px: f32,
}

pub const CAPTION: TypeScale = TypeScale { px: 12.0 };
pub const LABEL: TypeScale = TypeScale { px: 14.0 };
pub const DISPLAY: TypeScale = TypeScale { px: 28.0 };
pub const MICRO: TypeScale = TypeScale { px: 11.0 };
