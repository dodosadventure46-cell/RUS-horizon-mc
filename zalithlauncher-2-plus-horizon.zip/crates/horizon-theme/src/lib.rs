//! Horizon Android design tokens
pub const FONT: &str = "Bricolage Grotesque";
pub const BODY_FONT: &str = "Plus Jakarta Sans";
pub const MONO: &str = "JetBrains Mono";
pub const PIXEL: &str = "Pixelify Sans";

pub const RADIUS: f32 = 22.0;
pub const RADIUS_PLATE: f32 = 18.0;

pub struct Palette {
    pub page: u32,
    pub plate: u32,
    pub plate_soft: u32,
    pub rule: u32,
    pub ink: u32,
    pub ink_soft: u32,
    pub accent: u32,
    pub on_accent: u32,
}

pub const DARK: Palette = Palette {
    page: 0x0B0F17,
    plate: 0x111827,
    plate_soft: 0x1E293B,
    rule: 0x334155,
    ink: 0xF8FAFC,
    ink_soft: 0x94A3B8,
    accent: 0xA8C7FA,
    on_accent: 0x0F172A,
};
