//! ZalithLauncher 2 Plus v2.3 UI Theme, UI Scale & Custom Image/Video Background Engine
use crate::hud::{HudAtlas, HudBatch, Rect};
use std::path::Path;

pub fn preference(dir: &Path, key: &str) -> Option<String> {
    let text = std::fs::read_to_string(dir.join("horizon.txt")).ok()?;
    text.lines().find_map(|l| {
        let (k, v) = l.split_once(':')?;
        (k.trim() == key).then(|| v.trim().to_owned())
    })
}

pub(crate) fn set_preference(dir: &Path, key: &str, value: Option<&str>) {
    let text = std::fs::read_to_string(dir.join("horizon.txt")).unwrap_or_default();
    let mut lines: Vec<String> = text
        .lines()
        .filter(|l| l.split_once(':').is_none_or(|(k, _)| k.trim() != key))
        .map(str::to_owned)
        .collect();
    if let Some(v) = value {
        lines.push(format!("{key}:{v}"));
    }
    let mut out = lines.join("\n");
    out.push('\n');
    let _ = std::fs::write(dir.join("horizon.txt"), out);
}

pub mod color {
    use horizon_theme::DARK as P;

    pub const fn hex(c: u32, a: u8) -> u32 {
        (a as u32) << 24 | (c & 0xff) << 16 | (c >> 8 & 0xff) << 8 | (c >> 16 & 0xff)
    }

    pub const BG: u32 = hex(P.page, 82);
    pub const GLASS_SURFACE: u32 = hex(P.plate, 194);
    pub const RAISED: u32 = hex(P.ink, 86);
    pub const GLOW_BORDER: u32 = hex(P.accent, 68);
    pub const HOVER: u32 = hex(P.ink, 58);
    pub const BORDER: u32 = hex(P.rule, 120);
    pub const TEXT: u32 = hex(P.ink, 255);
    pub const MUTED: u32 = hex(P.ink_soft, 255);
    pub const ACCENT: u32 = hex(0xA8C7FA, 255);
    pub const ON_ACCENT: u32 = hex(0x091122, 255);

    pub(crate) fn with_alpha(c: u32, a: f32) -> u32 {
        let base = (c >> 24) as f32;
        (c & 0x00ff_ffff) | ((base * a.clamp(0.0, 1.0)).round() as u32) << 24
    }
}
