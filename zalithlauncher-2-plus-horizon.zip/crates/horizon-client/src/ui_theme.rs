//! ZalithLauncher 2 Plus v2.0 UI Theme, UI Scale & Custom Image/Video Background Engine
//! File: crates/horizon-client/src/ui_theme.rs
//! Preserves `preference()` and `set_preference()` on `horizon.txt` with zero-delay launch.

use crate::hud::{HudAtlas, HudBatch, Rect};
use std::path::Path;

/// Read a Horizon/Zalith preference from `horizon.txt` beside `options.txt`
pub fn preference(dir: &Path, key: &str) -> Option<String> {
    let text = std::fs::read_to_string(dir.join("horizon.txt")).ok()?;
    text.lines().find_map(|l| {
        let (k, v) = l.split_once(':')?;
        (k.trim() == key).then(|| v.trim().to_owned())
    })
}

/// Set (or with None remove) one preference in `horizon.txt`, keeping all engine keys intact.
pub(crate) fn set_preference(dir: &Path, key: &str, value: Option<&str>) {
    let text = std::fs::read_to_string(dir.join("horizon.txt")).unwrap_or_default();
    let mut lines: Vec<String> = text
        .lines()
        .filter(|l| l.split_once(':').is_none_or(|(k, _)| k.trim() != key))
        .map(str::to_owned)
        .collect();
    if let Some(v) = value {
        lines.push(format!("{key}:{v}"));
    }
    let mut out = lines.join("\n");
    out.push('\n');
    let _ = std::fs::write(dir.join("horizon.txt"), out);
}

/// Read user UI scale factor (0.75 to 1.25, default 1.0)
pub fn ui_scale_factor(dir: &Path) -> f32 {
    preference(dir, "zalith_ui_scale_pct")
        .and_then(|v| v.parse::<f32>().ok())
        .map(|pct| (pct / 100.0).clamp(0.75, 1.25))
        .unwrap_or(1.0)
}

/// Read in-game touch HUD scale factor (0.50 to 1.50, default 1.0)
pub fn hud_scale_factor(dir: &Path) -> f32 {
    preference(dir, "zalith_hud_scale_pct")
        .and_then(|v| v.parse::<f32>().ok())
        .map(|pct| (pct / 100.0).clamp(0.50, 1.50))
        .unwrap_or(1.0)
}

/// Custom Background (Image & Video) configuration with automatic in-game pause
#[derive(Clone, Debug)]
pub struct ZalithCustomBackground {
    pub media_path: String,
    pub is_video: bool,
    pub video_muted: bool,
    pub auto_pause_ingame: bool,
    pub dim_pct: u8,
    pub glass_opacity_pct: u8,
}

impl ZalithCustomBackground {
    pub fn load(dir: &Path) -> Self {
        let media_path = preference(dir, "zalith_bg_media").unwrap_or_else(|| "none".to_owned());
        let bg_type = preference(dir, "zalith_bg_type").unwrap_or_else(|| "image".to_owned());
        let is_video = bg_type.eq_ignore_ascii_case("video")
            || media_path.ends_with(".mp4")
            || media_path.ends_with(".webm")
            || media_path.ends_with(".gif");
        let video_muted = preference(dir, "zalith_bg_video_muted")
            .map(|v| v != "false")
            .unwrap_or(true);
        let auto_pause_ingame = preference(dir, "zalith_bg_auto_pause_ingame")
            .map(|v| v != "false")
            .unwrap_or(true);
        let dim_pct = preference(dir, "zalith_bg_dim_pct")
            .and_then(|v| v.parse::<u8>().ok())
            .unwrap_or(32)
            .clamp(5, 90);
        let glass_opacity_pct = preference(dir, "zalith_glass_opacity_pct")
            .and_then(|v| v.parse::<u8>().ok())
            .unwrap_or(76)
            .clamp(35, 95);
        Self {
            media_path,
            is_video,
            video_muted,
            auto_pause_ingame,
            dim_pct,
            glass_opacity_pct,
        }
    }
}

pub mod color {
    use horizon_theme::DARK as P;

    pub const fn hex(c: u32, a: u8) -> u32 {
        (a as u32) << 24 | (c & 0xff) << 16 | (c >> 8 & 0xff) << 8 | (c >> 16 & 0xff)
    }

    /// Backdrop scrim over custom Zalith 2 image/video wallpaper
    pub const BG: u32 = hex(P.page, 82);
    /// Zalith 2 Translucent Material 3 Glass Surface
    pub const GLASS_SURFACE: u32 = hex(P.plate, 194);
    /// Soft elevated card plate inside Zalith 2 Plus Bento Grid
    pub const RAISED: u32 = hex(P.ink, 86);
    /// Outer glowing border ring around Bento cards
    pub const GLOW_BORDER: u32 = hex(P.accent, 68);
    /// Active/hover interactive surface
    pub const HOVER: u32 = hex(P.ink, 58);
    /// Subtle 1px hairline border
    pub const BORDER: u32 = hex(P.rule, 120);
    /// High-contrast foreground text
    pub const TEXT: u32 = hex(P.ink, 255);
    /// Secondary muted metadata text
    pub const MUTED: u32 = hex(P.ink_soft, 255);
    /// Zalith 2 Plus Active Accent (#A8C7FA)
    pub const ACCENT: u32 = hex(0xA8C7FA, 255);
    pub const ON_ACCENT: u32 = hex(0x091122, 255);
    /// Ely.by Emerald Badge Color
    pub const ELY_BADGE: u32 = hex(0x34D399, 255);
    /// Java Shader Gold Badge Color
    pub const SHADER_BADGE: u32 = hex(0xFBBF24, 255);

    pub(crate) fn with_alpha(c: u32, a: f32) -> u32 {
        let base = (c >> 24) as f32;
        (c & 0x00ff_ffff) | ((base * a.clamp(0.0, 1.0)).round() as u32) << 24
    }
}
