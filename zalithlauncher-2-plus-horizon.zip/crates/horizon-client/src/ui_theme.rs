//! ZalithLauncher 2 Plus UI Theme & Custom Background Renderer for Vasysik/horizon-android
//! File: crates/horizon-client/src/ui_theme.rs
//! Preserves `preference()` and `set_preference()` on `horizon.txt` while rendering
//! ZalithLauncher 2 Plus frosted glass cards and custom user wallpapers.

use crate::hud::{HudAtlas, HudBatch, Rect};
use std::path::Path;

/// Read a Horizon/Zalith preference from `horizon.txt` beside `options.txt`
pub fn preference(dir: &Path, key: &str) -> Option<String> {
    let text = std::fs::read_to_string(dir.join("horizon.txt")).ok()?;
    text.lines().find_map(|l| {
        let (k, v) = l.split_once(':')?;
        (k.trim() == key).then(|| v.trim().to_owned())
    })
}

/// Set (or with None remove) one preference in `horizon.txt`, keeping all engine keys intact.
pub(crate) fn set_preference(dir: &Path, key: &str, value: Option<&str>) {
    let text = std::fs::read_to_string(dir.join("horizon.txt")).unwrap_or_default();
    let mut lines: Vec<String> = text
        .lines()
        .filter(|l| l.split_once(':').is_none_or(|(k, _)| k.trim() != key))
        .map(str::to_owned)
        .collect();
    if let Some(v) = value {
        lines.push(format!("{key}:{v}"));
    }
    let mut out = lines.join("\n");
    out.push('\n');
    let _ = std::fs::write(dir.join("horizon.txt"), out);
}

/// ZalithLauncher 2 Plus Custom Background & Translucent Glass Configuration
pub struct ZalithBackgroundStyle {
    pub wallpaper_id: &'static str,
    pub blur_px: u32,
    pub scrim_alpha: u8,
    pub glass_alpha: u8,
}

pub const ZALITH_BG_DEFAULT: ZalithBackgroundStyle = ZalithBackgroundStyle {
    wallpaper_id: "zalith-plus-bg",
    blur_px: 2,
    scrim_alpha: 82,
    glass_alpha: 184,
};

pub mod color {
    use horizon_theme::DARK as P;

    pub const fn hex(c: u32, a: u8) -> u32 {
        (a as u32) << 24 | (c & 0xff) << 16 | (c >> 8 & 0xff) << 8 | (c >> 16 & 0xff)
    }

    /// Backdrop scrim over custom Zalith 2 wallpaper
    pub const BG: u32 = hex(P.page, 82);
    /// Zalith 2 Translucent Material 3 Glass Surface (72% opacity)
    pub const GLASS_SURFACE: u32 = hex(P.plate, 184);
    /// Soft elevated card plate inside Zalith 2 Plus Bento Grid
    pub const RAISED: u32 = hex(P.ink, 36);
    /// Active/hover interactive surface
    pub const HOVER: u32 = hex(P.ink, 52);
    /// Subtle 1px hairline border
    pub const BORDER: u32 = hex(P.rule, 110);
    /// High-contrast foreground text
    pub const TEXT: u32 = hex(P.ink, 255);
    /// Secondary muted metadata text
    pub const MUTED: u32 = hex(P.ink_soft, 255);
    /// Zalith 2 Plus Active Accent (Zalith 2 Plus Pastel: #A8C7FA)
    pub const ACCENT: u32 = hex(0xA8C7FA, 255);
    pub const ON_ACCENT: u32 = hex(0x0F172A, 255);

    pub(crate) fn with_alpha(c: u32, a: f32) -> u32 {
        let base = (c >> 24) as f32;
        (c & 0x00ff_ffff) | ((base * a.clamp(0.0, 1.0)).round() as u32) << 24
    }
}
