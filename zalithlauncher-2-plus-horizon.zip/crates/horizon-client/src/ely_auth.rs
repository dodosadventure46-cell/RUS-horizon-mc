//! Ely.by Authentication & Skin System Integration for ZalithLauncher 2 Plus Horizon
//! Official API Reference: https://docs.ely.by/en/minecraft-auth.html

use std::path::Path;
use crate::ui_theme::{preference, set_preference};

pub const ELY_AUTH_BASE: &str = "https://authserver.ely.by";
pub const ELY_SKIN_BASE: &str = "http://skinsystem.ely.by/textures";

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum AccountProvider {
    Offline,
    ElyBy,
    Microsoft,
}

impl AccountProvider {
    pub fn from_pref(dir: &Path, ms_signed_in: bool) -> Self {
        match preference(dir, "account_active_type").as_deref() {
            Some("elyby") | Some("ely.by") => Self::ElyBy,
            Some("microsoft") => Self::Microsoft,
            Some("offline") => Self::Offline,
            _ => if ms_signed_in { Self::Microsoft } else { Self::ElyBy },
        }
    }
}
