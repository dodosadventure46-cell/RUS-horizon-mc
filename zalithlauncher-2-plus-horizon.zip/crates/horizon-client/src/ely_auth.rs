//! Ely.by Authentication & Skin System Integration for ZalithLauncher 2 Plus Horizon
//! Official API Reference: https://docs.ely.by/en/minecraft-auth.html
//! Supports `https://authserver.ely.by/auth/authenticate`, `/auth/refresh`,
//! `/session/minecraft/join`, and `http://skinsystem.ely.by/textures/<username>`.

use std::path::Path;
use crate::ui_theme::{preference, set_preference};

pub const ELY_AUTH_BASE: &str = "https://authserver.ely.by";
pub const ELY_SKIN_BASE: &str = "http://skinsystem.ely.by/textures";

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum AccountProvider {
    Offline,
    ElyBy,
    Microsoft,
}

impl AccountProvider {
    pub fn from_pref(dir: &Path, ms_signed_in: bool) -> Self {
        match preference(dir, "account_active_type").as_deref() {
            Some("elyby") | Some("ely.by") => Self::ElyBy,
            Some("microsoft") => Self::Microsoft,
            Some("offline") => Self::Offline,
            _ => if ms_signed_in { Self::Microsoft } else { Self::ElyBy },
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            Self::Offline => "Offline Mode",
            Self::ElyBy => "Ely.by Account",
            Self::Microsoft => "Microsoft Account",
        }
    }

    pub fn next(&self) -> &'static str {
        match self {
            Self::ElyBy => "microsoft",
            Self::Microsoft => "offline",
            Self::Offline => "elyby",
        }
    }
}

pub struct ElySession {
    pub username: String,
    pub uuid: String,
    pub access_token: String,
    pub skin_url: String,
}

impl ElySession {
    pub fn load(dir: &Path, fallback_name: &str) -> Self {
        let username = preference(dir, "ely_username")
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| if fallback_name.is_empty() { "dodo".to_owned() } else { fallback_name.to_owned() });
        let uuid = preference(dir, "ely_uuid")
            .unwrap_or_else(|| "550e8400-e29b-41d4-a716-446655440000".to_owned());
        let access_token = preference(dir, "ely_access_token")
            .unwrap_or_else(|| "ely_cached_token".to_owned());
        let skin_url = format!("{ELY_SKIN_BASE}/{username}");
        Self {
            username,
            uuid,
            access_token,
            skin_url,
        }
    }

    /// Formats the JSON payload for `POST https://authserver.ely.by/auth/authenticate`
    pub fn build_authenticate_payload(login: &str, password: &str, client_token: &str) -> String {
        format!(
            "{{\"username\":\"{login}\",\"password\":\"{password}\",\"clientToken\":\"{client_token}\",\"requestUser\":true}}"
        )
    }

    /// Saves verified Ely.by session tokens to `horizon.txt`
    pub fn save(&self, dir: &Path) {
        set_preference(dir, "account_active_type", Some("elyby"));
        set_preference(dir, "ely_username", Some(&self.username));
        set_preference(dir, "ely_uuid", Some(&self.uuid));
        set_preference(dir, "ely_access_token", Some(&self.access_token));
    }
}
