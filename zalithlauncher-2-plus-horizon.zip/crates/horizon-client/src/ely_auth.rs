//! Ely.by Authentication & Skin System Integration for ZalithLauncher 2 Plus Horizon
//! Official API Reference: https://docs.ely.by/en/minecraft-auth.html

pub const ELY_AUTH_BASE: &str = "https://authserver.ely.by";
pub const ELY_SKIN_BASE: &str = "http://skinsystem.ely.by/textures";
