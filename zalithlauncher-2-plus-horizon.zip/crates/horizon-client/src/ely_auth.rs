//! Ely.by Authentication & Skin System Integration
pub const ELY_AUTH_BASE: &str = "https://authserver.ely.by";
pub const ELY_SKIN_BASE: &str = "http://skinsystem.ely.by/textures";
