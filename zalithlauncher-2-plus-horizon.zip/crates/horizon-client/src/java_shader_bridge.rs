//! Minecraft Java Shader Compatibility Bridge (Fixes Issue #5960 gl_FogFragCoord for MakeUp-UltraFast)
//! Leaves BSL 100% untouched while declaring `gl_FogFragCoord` for shaders that use GLSL 1.20 fog varyings.

pub fn patch_gl_fog_frag_coord_if_needed(src: &str) -> String {
    if src.contains("gl_FogFragCoord") && !src.contains("float hz_gl_FogFragCoord") {
        let body = src.replace("gl_FogFragCoord", "hz_gl_FogFragCoord");
        if let Some(nl_pos) = body.find('\n') {
            let (first, rest) = body.split_at(nl_pos + 1);
            if first.trim_start().starts_with("#version") {
                return format!("{first}float hz_gl_FogFragCoord = 0.0;\n{rest}");
            }
        }
        return format!("float hz_gl_FogFragCoord = 0.0;\n{body}");
    }
    src.to_owned()
}
