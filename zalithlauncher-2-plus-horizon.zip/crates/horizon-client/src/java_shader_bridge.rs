//! Minecraft Java Shader (.zip GLSL OptiFine/Iris -> Horizon WGSL/Vulkan Anti-Fog Compatibility Bridge)
//! Normalizes `gl_Fog`, `fogStart`, `fogEnd`, `depthtex1`/`depthtex2`, and `RENDERTARGETS` so
//! non-BSL shaders (Chocapic, MakeUp-UltraFast, Sildur's, Complementary, etc.) render clear terrain.

pub fn normalize_java_glsl_source(src: &str) -> String {
    src.replace("gl_Fog.start", "128.0")
       .replace("gl_Fog.end", "256.0")
       .replace("gl_Fog.scale", "0.0078125")
       .replace("gl_Fog.density", "0.0008")
       .replace("depthtex2", "depthtex0")
}
