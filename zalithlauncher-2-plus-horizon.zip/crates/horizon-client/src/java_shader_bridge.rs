//! Minecraft Java Shader Compatibility Bridge
