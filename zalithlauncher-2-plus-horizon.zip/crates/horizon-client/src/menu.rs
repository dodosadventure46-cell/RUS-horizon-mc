//! ZalithLauncher 2 Plus v2.0 Bento Grid Dashboard, Real-Time Stats, Custom BG, UI Scale,
//! Java Shader Bridge, Pre-Baked .hnmod Runtime Toggle & Ely.by Manager.

use crate::ui_theme::{color, preference, set_preference};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ZalithNavTab {
    PlayDashboard,
    TouchControlsHud,
    HnmodAndHmodManager,
    JavaShaderManager,
    CustomBackgroundAndScale,
    ElyByAccountManager,
}

pub mod layout {
    pub const LEFT_PILL_WIDTH_DP: f32 = 42.0;
    pub const TOP_BAR_HEIGHT_DP: f32 = 52.0;
    pub const BENTO_GRID_GAP_DP: f32 = 12.0;
    pub const RIGHT_PROFILE_CARD_WIDTH_DP: f32 = 244.0;
    pub const LAUNCH_PILL_RADIUS_DP: f32 = 24.0;
    pub const CARD_CORNER_RADIUS_DP: f32 = 24.0;
    pub const ACCENT_COLOR_HEX: u32 = 0xA8C7FA;
}
