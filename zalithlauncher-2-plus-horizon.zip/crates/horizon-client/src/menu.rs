//! Horizon Android Layout Constants
