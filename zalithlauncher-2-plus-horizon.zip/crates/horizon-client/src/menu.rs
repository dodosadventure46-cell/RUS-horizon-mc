//! ZalithLauncher 2 Plus Bento Grid Dashboard & .hnmod Manager for Vasysik/horizon-android
//! File: crates/horizon-client/src/menu.rs
//! Implements ZalithLauncher 2 Plus Left Collapsible Pill + Center 2x2 Statistics/Changelog/Log
//! Bento Grid + Right Tall Profile Card ("Luncurkan" pill button) + .hnmod & .hmod support.

use crate::ui_theme::{color, preference, set_preference, ZALITH_BG_DEFAULT};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ZalithNavTab {
    PlayDashboard,
    TouchControlsHud,
    HnmodAndHmodManager,
    EngineSettings,
}

pub struct ZalithLauncherShell {
    pub active_tab: ZalithNavTab,
    pub active_profile: &'static str,
    pub active_account: &'static str,
    pub renderer_backend: &'static str,
    pub hnmod_support_enabled: bool,
    pub custom_wallpaper_enabled: bool,
}

impl Default for ZalithLauncherShell {
    fn default() -> Self {
        Self {
            active_tab: ZalithNavTab::PlayDashboard,
            active_profile: "26.3 Horizon (.hnmod & .hmod)",
            active_account: "dodo",
            renderer_backend: "vulkan",
            hnmod_support_enabled: true,
            custom_wallpaper_enabled: true,
        }
    }
}

/// Layout geometry constants matching ZalithLauncher 2 Plus Bento Grid & Right Profile Card
pub mod layout {
    pub const LEFT_PILL_WIDTH_DP: f32 = 44.0;
    pub const TOP_BAR_HEIGHT_DP: f32 = 52.0;
    pub const BENTO_GRID_GAP_DP: f32 = 14.0;
    pub const RIGHT_PROFILE_CARD_WIDTH_DP: f32 = 248.0;
    pub const LAUNCH_PILL_RADIUS_DP: f32 = 24.0;
    pub const CARD_CORNER_RADIUS_DP: f32 = 24.0;
    pub const ACCENT_COLOR_HEX: u32 = 0xA8C7FA;
}
