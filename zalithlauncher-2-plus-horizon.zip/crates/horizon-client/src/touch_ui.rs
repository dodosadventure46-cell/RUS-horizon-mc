//! Zalith 2 Plus Touch Controls & Adjustable HUD Scale
use crate::{
    hud::{HudAtlas, HudBatch, rgba},
    osk::{Keyboard, Output},
};
use std::{
    collections::BTreeMap,
    time::{Duration, Instant},
};
use winit::{event::TouchPhase, keyboard::KeyCode};

#[derive(Clone, Copy, Debug)]
pub struct TouchSlot {
    pub id: &'static str,
    pub label: &'static str,
    pub x_pct: f32,
    pub y_pct: f32,
    pub w_dp: f32,
    pub h_dp: f32,
    pub alpha: f32,
    pub shape: &'static str,
}

pub fn resolve_slot_rect_scaled(slot: &TouchSlot, screen_w: f32, screen_h: f32, hud_scale: f32) -> [f32; 4] {
    let s = hud_scale.clamp(0.50, 1.50);
    let w = slot.w_dp * s;
    let h = slot.h_dp * s;
    let cx = (slot.x_pct / 100.0) * screen_w;
    let cy = (slot.y_pct / 100.0) * screen_h;
    [
        (cx - w * 0.5).clamp(4.0, (screen_w - w - 4.0).max(4.0)),
        (cy - h * 0.5).clamp(4.0, (screen_h - h - 4.0).max(4.0)),
        w,
        h,
    ]
}
