//! Zalith 2 Plus Touch Controls & Adjustable HUD Scale for Vasysik/horizon-android
//! File: crates/horizon-client/src/touch_ui.rs
//! Preserves all 28 auxiliary keys, relative touch gestures, virtual mouse, and OSK hooks,
//! plus dynamic HUD scaling (`zalith_hud_scale_pct` from 50% to 150%).

use crate::{
    hud::{HudAtlas, HudBatch, rgba},
    osk::{Keyboard, Output},
};
use std::{
    collections::BTreeMap,
    time::{Duration, Instant},
};
use winit::{event::TouchPhase, keyboard::KeyCode};

#[derive(Clone, Copy, Debug)]
pub struct TouchSlot {
    pub id: &'static str,
    pub label: &'static str,
    pub x_pct: f32,
    pub y_pct: f32,
    pub w_dp: f32,
    pub h_dp: f32,
    pub alpha: f32,
    pub shape: &'static str,
}

/// Active Zalith 2 Plus Touch Layout Preset: zalith-default
pub const ZALITH_TOUCH_SLOTS: &[TouchSlot] = &[
    TouchSlot { id: "dpad_joystick", label: "Zalith Joystick", x_pct: 15.0, y_pct: 68.0, w_dp: 116.0, h_dp: 116.0, alpha: 0.75, shape: "circle" },
    TouchSlot { id: "btn_jump", label: "Jump", x_pct: 88.0, y_pct: 70.0, w_dp: 60.0, h_dp: 60.0, alpha: 0.75, shape: "circle" },
    TouchSlot { id: "btn_sneak", label: "Shift", x_pct: 76.0, y_pct: 74.0, w_dp: 52.0, h_dp: 52.0, alpha: 0.75, shape: "circle" },
    TouchSlot { id: "btn_sprint", label: "Ctrl", x_pct: 26.0, y_pct: 46.0, w_dp: 48.0, h_dp: 48.0, alpha: 0.75, shape: "circle" },
    TouchSlot { id: "mouse_lmb", label: "Attack (LMB)", x_pct: 88.0, y_pct: 40.0, w_dp: 84.0, h_dp: 36.0, alpha: 0.75, shape: "pill" },
    TouchSlot { id: "mouse_rmb", label: "Place (RMB)", x_pct: 88.0, y_pct: 52.0, w_dp: 84.0, h_dp: 36.0, alpha: 0.75, shape: "pill" },
    TouchSlot { id: "btn_swap", label: "Swap", x_pct: 74.0, y_pct: 52.0, w_dp: 52.0, h_dp: 32.0, alpha: 0.75, shape: "pill" },
    TouchSlot { id: "btn_drop", label: "Drop", x_pct: 74.0, y_pct: 38.0, w_dp: 50.0, h_dp: 32.0, alpha: 0.75, shape: "pill" },
    TouchSlot { id: "btn_inv", label: "Inv", x_pct: 76.0, y_pct: 91.0, w_dp: 46.0, h_dp: 34.0, alpha: 0.85, shape: "rounded" },
    TouchSlot { id: "btn_pick", label: "Pick", x_pct: 24.0, y_pct: 91.0, w_dp: 46.0, h_dp: 34.0, alpha: 0.75, shape: "rounded" },
    TouchSlot { id: "btn_esc", label: "Esc", x_pct: 7.0, y_pct: 8.0, w_dp: 46.0, h_dp: 28.0, alpha: 0.80, shape: "pill" },
    TouchSlot { id: "btn_chat", label: "Chat", x_pct: 16.0, y_pct: 8.0, w_dp: 48.0, h_dp: 28.0, alpha: 0.80, shape: "pill" },
    TouchSlot { id: "btn_slash", label: "/", x_pct: 24.0, y_pct: 8.0, w_dp: 36.0, h_dp: 28.0, alpha: 0.80, shape: "pill" },
    TouchSlot { id: "btn_tab", label: "Tab", x_pct: 32.0, y_pct: 8.0, w_dp: 44.0, h_dp: 28.0, alpha: 0.80, shape: "pill" },
    TouchSlot { id: "btn_f3", label: "F3", x_pct: 40.0, y_pct: 8.0, w_dp: 40.0, h_dp: 28.0, alpha: 0.80, shape: "pill" },
    TouchSlot { id: "btn_f5", label: "F5", x_pct: 48.0, y_pct: 8.0, w_dp: 40.0, h_dp: 28.0, alpha: 0.80, shape: "pill" },
    TouchSlot { id: "btn_f1", label: "F1", x_pct: 56.0, y_pct: 8.0, w_dp: 40.0, h_dp: 28.0, alpha: 0.75, shape: "pill" },
    TouchSlot { id: "btn_vmouse", label: "Mouse", x_pct: 92.0, y_pct: 8.0, w_dp: 56.0, h_dp: 28.0, alpha: 0.85, shape: "pill" },
    TouchSlot { id: "btn_keyboard", label: "OSK", x_pct: 82.0, y_pct: 8.0, w_dp: 48.0, h_dp: 28.0, alpha: 0.85, shape: "pill" },
];

pub const KEYS: [(&str, KeyCode); 28] = [
    ("F1", KeyCode::F1), ("F2", KeyCode::F2), ("F3", KeyCode::F3), ("F4", KeyCode::F4),
    ("F5", KeyCode::F5), ("F6", KeyCode::F6), ("F7", KeyCode::F7), ("F8", KeyCode::F8),
    ("F9", KeyCode::F9), ("F10", KeyCode::F10), ("F11", KeyCode::F11), ("F12", KeyCode::F12),
    ("Tab", KeyCode::Tab), ("Swap", KeyCode::KeyF), ("Drop", KeyCode::KeyQ), ("Adv", KeyCode::KeyL),
    ("Chat", KeyCode::KeyT), ("/", KeyCode::Slash), ("Enter", KeyCode::Enter), ("Esc", KeyCode::Escape),
    ("Shift", KeyCode::ShiftLeft), ("Ctrl", KeyCode::ControlLeft), ("Inv", KeyCode::KeyE),
    ("Pick", KeyCode::ContextMenu), ("F3+B", KeyCode::KeyB), ("F3+G", KeyCode::KeyG),
    ("F3+A", KeyCode::KeyA), ("F3+T", KeyCode::KeyT),
];

/// Converts normalized percentage slot coordinates to logical screen dp rectangle with HUD scale
pub fn resolve_slot_rect_scaled(slot: &TouchSlot, screen_w: f32, screen_h: f32, hud_scale: f32) -> [f32; 4] {
    let s = hud_scale.clamp(0.50, 1.50);
    let w = slot.w_dp * s;
    let h = slot.h_dp * s;
    let cx = (slot.x_pct / 100.0) * screen_w;
    let cy = (slot.y_pct / 100.0) * screen_h;
    [
        (cx - w * 0.5).clamp(4.0, (screen_w - w - 4.0).max(4.0)),
        (cy - h * 0.5).clamp(4.0, (screen_h - h - 4.0).max(4.0)),
        w,
        h,
    ]
}
