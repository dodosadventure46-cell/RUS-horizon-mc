#!/usr/bin/env python3
import json
import pathlib
import subprocess
import urllib.request
import zipfile

root = pathlib.Path(".")
version = json.loads((root / "research-lock.json").read_text(encoding="utf-8"))["minecraft"]["version"]
dest = root / ".local/horizon-client" / version
dest.mkdir(parents=True, exist_ok=True)

release_url = "https://github.com/Vasysik/horizon-android/releases/download/v0.7.6/Horizon-Android-0.7.6-arm64-v8a.apk"
ref_apk = pathlib.Path("/tmp/horizon-ref.apk")
try:
    print(f"Mengambil tabel mesin (engine-data.zip) untuk Minecraft {version}...")
    urllib.request.urlretrieve(release_url, ref_apk)
    with zipfile.ZipFile(ref_apk) as apk:
        with zipfile.ZipFile(apk.open("assets/engine-data.zip")) as ed:
            ed.extractall(dest)
    print("Berhasil menyiapkan generated engine tables di", dest)
except Exception as e:
    print("Fallback ke tools/android_prepare.py:", e)
    subprocess.run(["python3", "tools/android_prepare.py"], check=True)
