# Horizon Android v2.7 — Sinkronisasi Rilis Baru v0.7.7, Self-Healing Builder & Nama Asli Horizon Android

Penyebab gagal build sebelumnya (dan solusinya di v2.7):
1. **Rilis Baru `Horizon Android 0.7.7` di Repo Pusat**: Hari ini `@Vasysik` merilis **v0.7.7** (1.846 commit baru di branch `android`), sehingga tabel mesin (`engine-data.zip`) dari **v0.7.6** tidak lagi cocok dengan kode Rust **v0.7.7**. Di v2.7, `tools/android_build.py` otomatis mengunduh `engine-data.zip` dari **v0.7.7** (`Horizon-Android-0.7.7-arm64-v8a.apk`).
2. **Proteksi Otomatis Meskipun Hanya Ganti ZIP**: Meskipun kamu hanya mengganti file `zalithlauncher-2-plus-horizon.zip` tanpa mengganti file `.yml`, `zalith_patcher.py` otomatis memblokir penyalinan `/tmp/horizon-upstream` dari Step 6 `.yml` lama dan memasang **4-Stage Self-Healing Builder** di `tools/android_build.py`.
3. **Nama Tetap "Horizon Android"**: Tidak mengubah nama aplikasi menjadi Zalith.
