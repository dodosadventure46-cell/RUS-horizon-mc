# ZalithLauncher-2-Plus-Horizon v2.2 — Paket Upgrade UI, Real-Time Stats, Custom BG (Image/Video), UI Scale, Java Shaders, .hnmod & Ely.by

Paket ini dirancang untuk repositori [`Vasysik/horizon-android`](https://github.com/Vasysik/horizon-android) (branch `android`).
File `.github/workflows/build-horizon-zalith2-apk.yml` kini dibuat **ringkas (~125 baris, tanpa `PYEOF` sama sekali)** agar tidak pernah terpotong saat di-*copy-paste* lewat browser HP Android, sedangkan seluruh kode patcher (`zalith_patcher.py` dan `prepare_tables.py`) dijalankan langsung dari dalam `zalithlauncher-2-plus-horizon.zip`.
