# ZalithLauncher-2-Plus-Horizon v2.3 — Shader Anti-Fog Fix, Download Progress Bar, Keystore Tetap (Update Tanpa Uninstall) & Custom BG di Settings

Paket ini dirancang untuk repositori [`Vasysik/horizon-android`](https://github.com/Vasysik/horizon-android) (`v0.7.6`).
Perbaikan utama di versi v2.3:
1. **Perbaikan Shader Java Selain BSL (Anti-Fog & Depth Normalizer)**: Mencegah shader selain BSL (seperti Chocapic, MakeUp-UltraFast, Sildur's, Complementary) menutupi seluruh daratan dengan kabut 100% akibat nilai `gl_Fog.end` / `depthtex2`.
2. **Progress Bar & Persentase Download Minecraft 26.3**: Menampilkan persentase total (`0%–100%`), hitungan item (`done / total`), tahapan (`Tahap X/6`), dan 2 *progress bar* berwarna di Kartu Profil Kanan serta Kartu Bento #4.
3. **Keystore Tetap (`zalith2-fixed.keystore`) — Update APK Tanpa Uninstall**: Menandatangani APK dengan sertifikat tetap sehingga setiap update APK berikutnya bisa langsung di-*install* menimpa aplikasi lama tanpa perlu uninstall dan tanpa perlu men-download ulang data Minecraft 26.3 (~500 MB).
4. **Menu Custom Background (Gambar & Video) Langsung di Halaman Settings**: Menambahkan panel pemilih Gambar/Video Background dan UI Scale langsung di tab **Settings** serta tombol pintas di halaman **Play**.
