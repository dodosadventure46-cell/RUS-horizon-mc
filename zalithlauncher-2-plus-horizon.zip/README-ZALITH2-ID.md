# ZalithLauncher-2-Plus-Horizon — Paket Modifikasi UI ZalithLauncher 2 Plus & Support .hnmod untuk Horizon Android

Paket ini dihasilkan secara otomatis dari **Horizon Zalith 2 Plus UI Studio** untuk repositori [`Vasysik/horizon-android`](https://github.com/Vasysik/horizon-android) (branch `android`).
Seluruh fungsi asli mesin **Horizon (Minecraft Rust Edition)** tetap **100% sama**, ditambah **tampilan Bento Grid ZalithLauncher 2 Plus** dan **dukungan penuh mod native `.hnmod` & `.hmod` di Android**.

## Fitur Baru yang Diaktifkan
1. **UI ZalithLauncher 2 Plus**:
   - Baris atas: **ZalithLauncher 2 Plus** (`a fork of Zalith Launcher 2`) + 5 ikon aksi cepat di kanan atas.
   - Panel samping kiri dapat disembunyikan (*collapsible left pill drawer*).
   - **2x2 Bento Grid** di tengah: *Play Time (Last 7 Days)* 7-bar chart, *Today's Statistics (0,0 h)*, *Changelog Plus 1.3*, dan *Last Game Log*.
   - **Kartu Profil Tinggi di Kanan**: Avatar piksel Minecraft Steve, nama akun (`dodo`), status *Offline/Microsoft*, *Novice*, *Play Time: 2,6 Hours*, pemilih versi, dan tombol kapsul **Luncurkan**.
2. **Dukungan Penuh Mod `.hnmod` (Horizon Native Mod) di Android**:
   - Membuka blokir `source_only_mod` di `crates/horizon-client/src/android/catalog.rs` dan `launcher/src/browser/horizon.rs`.
   - Mengizinkan impor & validasi file `.hnmod` (`horizon-native.json`) di `content_files.rs`, `documents.rs`, dan `crates/horizon-mods/src/manifest.rs`.

## Ringkasan Konfigurasi Tampilan Anda
- **Nama Build**: `ZalithLauncher-2-Plus-Horizon`
- **Tema Warna Aksen**: Zalith 2 Plus Pastel (`#A8C7FA`)
- **Background / Wallpaper**: Zalith 2 Plus Glass
- **Background Blur & Dimming**: Blur `2px` · Dimming `32%`
- **Opasitas Panel Kaca (MD3 Glass)**: `72%` · Radius Sudut `24dp`
- **Preset Touch Control HUD**: `zalith-default` (19 tombol aktif)
- **Renderer Engine**: `VULKAN` · Skala Resolusi `85%` · Render Distance `12 chunks`
