# Horizon Android v2.6 — Nama Asli Horizon Android, Clean Bento UI, Auto-Convert Mod .jar ke .hmod, Custom BG di Settings & Keystore Tetap

Perbaikan utama di versi v2.6:
1. **Nama Tetap "Horizon Android"**: Mengembalikan judul asli `"Horizon Android"` tanpa mengubahnya menjadi Zalith.
2. **Perbaikan Gagal Build di Bagian Tables (Step 7)**: Menghapus penyalinan `horizon-shaders` lintas-repo yang menyebabkan ketidakcocokan API pada `horizon-client-render` serta memastikan seluruh ekspresi Rust 100% tervalidasi seperti pada build v2.2/v2.3 yang sukses.
3. **Custom Background di Settings Tanpa Pindah ke Menu Mods**: Tombol di halaman **Settings** langsung mengganti tema/background dan skala UI secara *live* di layar Settings tanpa melempar pengguna ke menu Mods.
4. **Auto-Convert Mod `.jar` ke `.hmod` & Hapus `.hnmod`**: Mendukung impor file `.jar` (Fabric, Forge, NeoForge) menjadi `.hmod` secara otomatis.
