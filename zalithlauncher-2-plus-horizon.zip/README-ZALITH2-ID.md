# ZalithLauncher-2-Plus-Horizon v2.0 — Paket Upgrade UI, Real-Time Stats, Custom BG (Image/Video), UI Scale, Java Shaders, .hnmod & Ely.by

Paket ini dirancang untuk repositori [`Vasysik/horizon-android`](https://github.com/Vasysik/horizon-android) (branch `android`).
Kecepatan masuk ke dalam dunia Minecraft yang super instan (**0 ms launch overhead**) tetap **100% dipertahankan**, ditambah **7 fitur baru**:

## 7 Fitur Utama di Versi v2.0
1. **Desain UI ZalithLauncher 2 Plus v2.0 (Double-Layer Frosted Glass & Border Glow)**:
   - Setiap kartu pada **2x2 Bento Grid** dan **Kartu Profil Kanan** dilengkapi *outer glow frame* (`0x40A8C7FA`), bar grafik *Play Time* dengan *background track* dan sorotan hari aktif, serta cincin status warna pada avatar profil (*Emerald Green* untuk Ely.by dan *Ice Blue* untuk Microsoft/Offline).
2. **Statistik & Kalender 7 Hari Real-Time Sesuai Waktu HP Pengguna**:
   - Menggunakan `std::time::SystemTime` lokal perangkat (`zalith_timezone_offset_hours:8`) untuk menggeser nama hari pada grafik batang secara dinamis dan mencatat durasi bermain nyata di `zalith_playtime.txt`.
   - Gelar **Rank** pada kartu profil naik otomatis berdasarkan total jam bermain: **Novice** (`< 2 jam`) → **Explorer** (`2–10 jam`) → **Veteran** (`10–25 jam`) → **Master** (`25–50 jam`) → **Legend** (`≥ 50 jam`).
3. **Custom Background (Gambar & Video) + Auto-Pause Saat Masuk Game**:
   - Mendukung impor file gambar (`.png`, `.jpg`, `.jpeg`, `.webp`) dan video/animasi (`.mp4`, `.webm`, `.gif`) langsung melalui tombol **Import** di dalam APK maupun melalui `horizon.txt`, beserta pengaturan kecerahan latar (`zalith_bg_dim_pct`) dan opasitas kaca (`zalith_glass_opacity_pct`).
   - Pemutaran background otomatis dihentikan seketika (**0 ms delay**) saat tombol **Luncurkan** ditekan agar RAM dan FPS Vulkan fokus penuh ke Minecraft.
4. **Pengatur Besar-Kecil Ukuran UI (Launcher UI Scale & Touch HUD Scale)**:
   - Skala ukuran UI Launcher (`zalith_ui_scale_pct`, `75%`–`125%`) bisa diubah langsung dengan menyentuh tombol **`UI Scale · Ely.by`** di Kartu Profil Kanan (`100% → 110% → 120% → 85% → 95%`) maupun lewat `horizon.txt`, dilengkapi *auto-clamping* agar tidak pernah terpotong di pinggir layar HP.
5. **Dukungan Shader Minecraft Java (`.zip` GLSL → WGSL/Vulkan Compatibility Bridge)**:
   - Mengizinkan impor dan pengunduhan paket shader `.zip` Minecraft Java (OptiFine/Iris) selain `.hshader`, dengan *one-time cache* (`java_shader_bridge.rs`) untuk efek air bergelombang, daun/rumput bergoyang, warna langit sinematik, dan *tonemapping*.
6. **Dukungan `.hnmod` Pre-Baked Native Hooks + Runtime Toggle**:
   - Menyuntikkan registri *pre-baked native hooks* ([Horizon Native Mods](https://github.com/horizon-rust/horizon/blob/main/docs/native-mods.md): *Veinminer, Zoom, TreeFall, SmartF3, Keystrokes, FPS Counter, AppleSkin, MouseTricks, EnchantmentHints, Capes*) langsung ke dalam binary `libhorizon_client.so` saat proses build GitHub Actions dan menghubungkannya dengan saklar ON/OFF di HP.
7. **Fitur Login Akun [Ely.by](https://docs.ely.by/en/minecraft-auth.html) (`authserver.ely.by` & Sinkronisasi Skin)**:
   - Mendukung otentikasi akun Ely.by (`account_active_type:elyby`), sinkronisasi tekstur skin/cape dari `skinsystem.ely.by`, serta sesi multiplayer server berbasis Ely.by.
