# Horizon-Zalith2-Edition — Paket Modifikasi UI Zalith Launcher 2 untuk Horizon Android

Paket ini dihasilkan secara otomatis dari **Horizon Zalith 2 UI Studio** untuk repositori [`Vasysik/horizon-android`](https://github.com/Vasysik/horizon-android) (branch `android`).
Seluruh fungsi asli mesin **Horizon (Minecraft Rust Edition)**—termasuk renderer **Vulkan (wgpu)**, autentikasi Microsoft/Offline, pengunduh aset Mojang, dan pemuat mod native **`.hmod`**—tetap **100% sama**.

## Ringkasan Konfigurasi Tampilan Anda
- **Nama Build**: `Horizon-Zalith2-Edition`
- **Tema Warna Aksen**: Zalith Emerald (`#10B981`)
- **Background / Wallpaper**: Emerald Aurora Valley
- **Background Blur & Dimming**: Blur `8px` · Dimming `58%`
- **Opasitas Panel Kaca (MD3 Glass)**: `74%` · Radius Sudut `16dp`
- **Preset Touch Control HUD**: `zalith-default` (19 tombol aktif)
- **Renderer Engine**: `VULKAN` · Skala Resolusi `85%` · Render Distance `12 chunks`

## Daftar File di Dalam Paket ZIP Ini
1. `horizon.txt` — File konfigurasi preferensi Horizon Android (tema Zalith 2, path background, opasitas, dan koordinat tombol sentuh).
2. `crates/horizon-theme/src/lib.rs` — Token warna aksen Zalith 2, font, dan radius komponen.
3. `crates/horizon-client/src/ui_theme.rs` — Sistem render panel kaca transparan (*Material Design 3 Glass*) dan pemuat gambar *background* kustom.
4. `crates/horizon-client/src/touch_ui.rs` — Tata letak tombol sentuh (*Touch Controls HUD*) bergaya Zalith 2 beserta 28 tombol fungsi asli.
5. `crates/horizon-client/src/menu.rs` — Struktur halaman utama *Zalith 2 Left Sidebar + Right Profile Card + Bottom Launch Bar*.
6. `zalith2-ui.patch` — File *unified git patch* untuk diterapkan langsung dengan `git apply zalith2-ui.patch`.
7. `.github/workflows/build-horizon-zalith2-apk.yml` — Workflow GitHub Actions untuk meng-*compile* file `.apk` secara otomatis di cloud GitHub.

## Cara Menggunakan & Membuat File APK
### Cara 1: Otomatis via GitHub Actions (Tanpa Install SDK di Laptop/HP)
1. Fork repositori `https://github.com/Vasysik/horizon-android` ke akun GitHub Anda.
2. Ekstrak isi file ZIP ini ke dalam repositori hasil fork tersebut, lalu *commit* & *push* ke branch `android`.
3. Buka tab **Actions** di GitHub Anda, pilih workflow **Build Horizon Android (Zalith 2 UI Edition) APK**, lalu unduh file `.apk` yang sudah selesai dibuat.

### Cara 2: Build Lokal (Jika Sudah Memiliki Rust & Android NDK)
```bash
git clone -b android https://github.com/Vasysik/horizon-android.git
cd horizon-android
# Salin file dari ZIP ini atau jalankan:
git apply zalith2-ui.patch
python tools/android_build.py --abi arm64-v8a --public
```
