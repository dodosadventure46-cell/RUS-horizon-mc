//! Zalith Launcher 2 Dashboard & Navigation Layout for Vasysik/horizon-android
//! File: crates/horizon-client/src/menu.rs
//! Implements Zalith 2 Left Navigation Rail + Translucent Wallpaper Canvas + Bottom Launch Bar
//! while calling the exact same Horizon native game launch, asset verification, and .hmod hooks.

use crate::ui_theme::{color, preference, set_preference, ZALITH_BG_DEFAULT};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ZalithNavTab {
    PlayDashboard,
    TouchControlsHud,
    HmodContentManager,
    EngineSettings,
}

pub struct ZalithLauncherShell {
    pub active_tab: ZalithNavTab,
    pub active_profile: &'static str,
    pub active_account: &'static str,
    pub renderer_backend: &'static str,
    pub custom_wallpaper_enabled: bool,
}

impl Default for ZalithLauncherShell {
    fn default() -> Self {
        Self {
            active_tab: ZalithNavTab::PlayDashboard,
            active_profile: "Minecraft 26.3 (Horizon Native Rust)",
            active_account: "Vasysik_Rust",
            renderer_backend: "vulkan",
            custom_wallpaper_enabled: true,
        }
    }
}

/// Layout geometry constants matching Zalith Launcher 2 landscape handheld ergonomics
pub mod layout {
    pub const LEFT_RAIL_WIDTH_DP: f32 = 68.0;
    pub const TOP_STATUS_HEIGHT_DP: f32 = 48.0;
    pub const RIGHT_PROFILE_PANEL_WIDTH_DP: f32 = 280.0;
    pub const BOTTOM_LAUNCH_BAR_HEIGHT_DP: f32 = 64.0;
    pub const CARD_CORNER_RADIUS_DP: f32 = 16.0;
    pub const ACCENT_COLOR_HEX: u32 = 0x10B981;
}
